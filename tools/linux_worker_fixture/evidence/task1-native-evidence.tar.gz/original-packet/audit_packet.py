import ast,datetime,hashlib,json,re,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
load=lambda name:json.loads((root/name).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
index=load('index.json');manifest=load('amd64-manifest.json');config=load('amd64-config.json');intake=load('registry-intake.json')
md='sha256:'+sha(root/'amd64-manifest.json')
selected=next(x for x in index['manifests'] if x['digest']==md)
assert selected['platform']=={'architecture':'amd64','os':'linux'}
assert selected['size']==(root/'amd64-manifest.json').stat().st_size
assert manifest['config']['digest']=='sha256:'+sha(root/'amd64-config.json')
assert intake['linux_amd64_manifest_digest']==md
sbom=load('attestation-1-0.json');provenance=load('attestation-1-1.json')
assert any(x['digest'].get('sha256')==md.split(':')[1] for x in sbom['subject'])
assert any(x.get('digest',{}).get('sha1')==intake['official_git_commit'] for x in provenance['predicate']['materials'])
for item in intake['attestations']:
 assert item['digest']=='sha256:'+sha(root/item['file'])
assert config['config'].get('Volumes') is None
assert config['architecture']=='amd64' and config['os']=='linux'
assert 'PYTHON_VERSION=3.12.15' in config['config']['Env']
assert 'PYTHON_SHA256=c2c4321961fab0fb999d66e0cecf521c2ab3994c7992873ea99e306c1094fd5a' in config['config']['Env']
files=load('context/base-file-sha256.json')
keyfiles=['usr/local/bin/python3.12','usr/local/lib/libpython3.12.so.1.0','lib/ld-musl-x86_64.so.1','usr/lib/libcrypto.so.3']
assert all(name in files for name in keyfiles)
packages=sbom['predicate']['packages']
(root/'base-packages.json').write_text(json.dumps([dict(name=p['name'],version=p.get('versionInfo'),license_declared=p.get('licenseDeclared'),license_concluded=p.get('licenseConcluded'),source_url=p.get('downloadLocation'),external_refs=p.get('externalRefs')) for p in packages],indent=2)+'\n')
for package,expected_version in [('musl','1.2.5-r23'),('libcrypto3','3.5.9-r0'),('python','3.12.15')]:
 assert any(p['name']==package and p.get('versionInfo')==expected_version for p in packages)
for item in load('license-intake.json'):
 assert item['available'] and item['sha256']==sha(root/item['file'])
for item in load('aports-intake.json'):
 assert item['sha256']==sha(root/(item['package']+'-APKBUILD'))
assert load('zlib-r0-intake.json')['sha256']==sha(root/'zlib-r0-APKBUILD')
proposal=load('proposed-source.json')
assert proposal['src/quantmesh/research/linux_bootstrap.py']['current_sha256']==sha(Path('src/quantmesh/research/linux_bootstrap.py'))
assert proposal['src/quantmesh/research/linux_bootstrap.py']['proposed_sha256']==sha(root/'context/linux_bootstrap.py')
for source in (root/'proposed-source').rglob('*.py'):ast.parse(source.read_text())
ast.parse((root/'context/curate.py').read_text())
context=[dict(path=p.relative_to(root/'context').as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((root/'context').rglob('*')) if p.is_file()]
(root/'context-seal.json').write_text(json.dumps(context,indent=2)+'\n')
context_bytes=sum(p['bytes'] for p in context)
allbytes=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
free=shutil.disk_usage(root).free
record={'status':'PROPOSAL_READY_FOR_ROOT_REVIEW','source_base':'c545c02093b5f7e3d8dedb5ccc79b128c9dc014f','source_unchanged':True,'all_metadata_bindings_passed':True,'base_digest':md,'base_compressed_runtime_bytes':sum(l['size'] for l in manifest['layers']),'base_sbom_package_entries':len(packages),'individually_bound_base_file_sha256':{name:files[name] for name in keyfiles},'current_bootstrap_sha256':proposal['src/quantmesh/research/linux_bootstrap.py']['current_sha256'],'proposed_bootstrap_sha256':proposal['src/quantmesh/research/linux_bootstrap.py']['proposed_sha256'],'context_bytes':context_bytes,'artifact_bytes_excluding_context':allbytes-context_bytes,'new_owned_docker_image_bytes':0,'new_owned_docker_cache_bytes':0,'new_owned_container_bytes':0,'actual_introduced_local_files_bytes_before_audit_record':allbytes,'free_c_bytes':free,'temporary_total_ceiling_bytes':5000000000,'minimum_free_c_bytes':50000000000,'planning_reservation_bytes':1073741824,'planning_reservation_is_unmeasured_estimate':True,'unpacked_image_size_measured':False,'image_admitted':False,'native_qualified':False,'qualification_exit':int((root/'prerequisite-pending.exit').read_text().strip()),'runtime_layers_downloaded':False,'build_executed':False,'timestamp_utc':datetime.datetime.now(datetime.UTC).isoformat()}
assert free>=50000000000 and allbytes<=5000000000
assert record['qualification_exit']==2
(root/'packet-audit.json').write_text(json.dumps(record,indent=2)+'\n')
phases=[dict(phase='session_intake',free_c_bytes=103346520064,new_owned_image_bytes=0,new_owned_context_bytes=0,new_owned_artifact_bytes=0),dict(phase='packet_sealed',free_c_bytes=free,new_owned_image_bytes=0,new_owned_context_bytes=context_bytes,new_owned_artifact_bytes=allbytes-context_bytes,unpacked_image_size_measured=False)]
(root/'disk-phases.json').write_text(json.dumps(phases,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['status','context_bytes','artifact_bytes_excluding_context','free_c_bytes','native_qualified','qualification_exit','all_metadata_bindings_passed']}))
