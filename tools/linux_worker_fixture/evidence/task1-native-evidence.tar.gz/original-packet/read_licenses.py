import hashlib,json,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
urls={
 'CPython-LICENSE':'https://raw.githubusercontent.com/python/cpython/v3.12.15/LICENSE',
 'CPython-third-party-licenses.rst':'https://raw.githubusercontent.com/python/cpython/v3.12.15/Doc/license.rst',
 'OpenSSL-LICENSE.txt':'https://raw.githubusercontent.com/openssl/openssl/openssl-3.5.9/LICENSE.txt',
 'musl-COPYRIGHT':'https://git.musl-libc.org/cgit/musl/plain/COPYRIGHT?h=v1.2.5',
 'zlib-LICENSE':'https://raw.githubusercontent.com/madler/zlib/v1.3.2/LICENSE',
}
records=[]
for name,url in urls.items():
 try:
  with urllib.request.urlopen(url,timeout=30) as response: data=response.read(512*1024)
  (root/name).write_bytes(data)
  records.append(dict(file=name,url=url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),available=True))
 except Exception as exc:
  records.append(dict(file=name,url=url,available=False,error_type=type(exc).__name__))
(root/'license-intake.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records))
