import hashlib,json,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
url='https://api.github.com/repos/alpinelinux/aports/commits/3.23-stable'
req=urllib.request.Request(url,headers={'User-Agent':'QuantMesh-owned-admission'})
with urllib.request.urlopen(req,timeout=30) as r: commit=json.load(r)['sha']
records=[]
for pkg in ['musl','openssl','zlib']:
 url=f'https://raw.githubusercontent.com/alpinelinux/aports/{commit}/main/{pkg}/APKBUILD'
 with urllib.request.urlopen(url,timeout=30) as r: data=r.read(512*1024)
 (root/(pkg+'-APKBUILD')).write_bytes(data)
 records.append(dict(package=pkg,aports_commit=commit,url=url,sha256=hashlib.sha256(data).hexdigest()))
(root/'aports-intake.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records))
