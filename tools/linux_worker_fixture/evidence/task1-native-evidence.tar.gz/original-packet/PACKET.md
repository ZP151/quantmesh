# #172 Task1 — minimal native fixture admission packet

Status: **PROPOSAL_READY_FOR_ROOT_REVIEW; NO PULL/BUILD/NATIVE WITNESS RUN**.
Base/source: `c545c02093b5f7e3d8dedb5ccc79b128c9dc014f`.
Branch: `codex/0038-linux-native-qualification`, worktree
`C:/Users/15492/.codex-clean/worktrees/a718/QuantMesh`.
Old `codex/0038-linux-owned-worker`/`0e5fb0e` and ignored handoff/evidence remain.
Tracked code is unchanged. AGENTS.md has no authority following the user's
explicit revocation; this packet follows the approved Task1 plan and current
scope/privacy/real-evidence/resource instructions.

The user expressly authorized one temporary local test after starting Engine.
Long-term resources remain **AWS**, not this workstation. No cloud purchase or
server-delivered claim follows from local qualification. PR175/CI38352153020,
root files/locks/ACTIVE/CI, PR166/helper/vendor work are untouched.

## 1. Exact upstream identity and evidence

Metadata only was retrieved from official Docker registry/auth, Docker Official
Images/library repositories, CPython, Alpine aports, musl and OpenSSL sources.
No runtime layer was downloaded. Public registry token remained in memory and
was not saved; no private credentials/config/HOME were accessed by readers.

| Item | Bound identity / actual measurement |
|---|---|
| Official tag observed | `python:3.12.15-alpine3.23` (discovery only; never build from tag) |
| Linux amd64 manifest | `sha256:9ce5a4e59b833c002e1c4196c60ec0b38977e3235d626298ba7ffe2e64f5a30c` |
| Base config/image ID | `sha256:56d444819cc60d5188b3e0d64396cf76a0b3e64a952836cb3155f6dc5a7e80b9` |
| Official packaging Git | `2a3b794c223ab067d122719541cdd54a068732a5`, `3.12/alpine3.23` |
| Upstream Dockerfile SHA256 | `7b4aba1aa5ced667b28a704ea8786c6a59c372d21a145081532dad8f1edc4497` |
| CPython source tar SHA256 | `c2c4321961fab0fb999d66e0cecf521c2ab3994c7992873ea99e306c1094fd5a` |
| Four compressed runtime layers | **20,623,644 B**, as registry descriptors; layer digests/sizes in `registry-intake.json` |
| SPDX attestation blob | `sha256:8bdd41fb23daaa4cced8e60664b0b53c41aa3207e3a9aa14a128b7b2f0801bde` |
| SLSA provenance blob | `sha256:cf4c68500bcf04c883aa580c8d4ab2018cb14b8d0e588ae29c937e2526b1e20e` |

Manifest/config/attestation raw bytes were checked against descriptor SHA256
and byte sizes. SPDX subject references the exact amd64 manifest; provenance
contains the matching official packaging Git material. `packet-audit.json`
records the binding checks. This is a TLS/registry/digest provenance chain,
not a claim of independent signature verification or byte-for-byte rebuild.

Official source references are archived in `registry-intake.json`,
`license-intake.json`, `aports-intake.json` and `zlib-r0-intake.json`. Source URLs
and raw SPDX are retained; no fabricated digest or made-up package version is
used. The base's published config contains public `GPG_KEY` and no Volumes.
We deliberately do not inherit its config in the final image.

## 2. Proposed build context and license/hash closure

Review `context/Dockerfile` and `context/curate.py`. They are unexecuted proposals.
Build uses the pinned amd64 official base as a **temporary source stage**;
`RUN --network=none` executes only a fixed local stdlib curation script with
`python -B -I`. No apt/apk/pip/download/compile/remote Dockerfile frontend occurs.
Final stage is `FROM scratch`, one COPY of the curated root, numeric non-root
USER, explicit PATH/LANG/PYTHONDONTWRITEBYTECODE, and a fixed bootstrap entrypoint.

Final runtime selects only:

| Component | Exact version / evidence | License notices retained |
|---|---|---|
| CPython + pure stdlib + 22 declared native extensions | `3.12.15`; official source SHA above; immutable base layers; selected executable/shared-library SHA256 from bound SPDX | PSF-2.0/historical terms plus embedded third-party notices; full upstream LICENSE and `Doc/license.rst` |
| musl loader/libc | Alpine `musl 1.2.5-r23`; matching aports recipe/source+patch SHA512 closure | musl COPYRIGHT/MIT; no musl-utils/GNU executable copied |
| OpenSSL libcrypto only | Alpine `libcrypto3 3.5.9-r0`; matching openssl aports recipe/source+patch SHA512 closure | upstream Apache-2.0 LICENSE |
| QuantMesh fixed controller | Exact root source or explicit bytecode-only proposed bytes below | repository Apache-2.0 LICENSE |

The four individually bound base binaries' SHA256 values are recorded in
`packet-audit.json`: python3.12, libpython3.12.so.1.0, musl loader, libcrypto.so.3.
`base-file-sha256.json` has 887 published file hashes. Upstream SPDX does **not**
give per-file hashes for CPython pure stdlib/extensions; their entire base bytes
are pinned by manifest layers/config diff IDs. Curation measures every selected
runtime file afterwards in `runtime-files.json`. Those measurements/image ID
must be archived and checked before admission/native execution; they are not
invented now. The builder parses every selected ELF and fails if DT_NEEDED
exceeds `{libpython3.12.so.1.0, libc.musl-x86_64.so.1, libcrypto.so.3}`.

The source-stage SPDX lists **53 entries**, including meta records, pip and
GPL/LGPL/system components. `base-packages.json` retains every declared version,
license and source URL. These are not declared core QuantMesh dependencies or
silently relabelled permissive. Final selection excludes pip/site-packages,
ensurepip bundled wheels, all original optional dynload modules except the
explicit list, busybox/shell/apk/readline/gdbm/libnsl/tzdata/zlib and other base
system libraries. Optional stdlib features requiring excluded extensions are
unsupported: this image certifies fixed Task1 witnesses, not a complete Python
distribution or research Worker runtime. Base-stage upstream third-party bytes
remain disclosed transient build materials and require root acceptance.

For source accuracy, current zlib aports is `1.3.2-r1` whereas the base contains
`1.3.2-r0`; the exact r0 recipe was recovered instead of claiming the r1 recipe
describes old bytes. That library/module is excluded from final runtime.

## 3. Exact bootstrap and necessary bytecode-only proposal

Current unchanged root bootstrap SHA256:
`0ad062c7ace576ba7dc26746dfca71e3f9db15c83b02bf2c0844c6ef63ed1a82`.

The latest requirement says every Python child uses `-B` and
`PYTHONDONTWRITEBYTECODE=1`. Existing Task1 source omits these in several fixed
launch paths. `bytecode-only-proposal.patch` is a concrete **unapplied** small
patch for the three owned Task1 files: PID1 `-B`; known nonsecret env admission;
child clean env flag; fixture/descendant/abrupt-owner `-B`; isolation assertions.
It changes no containment protocol, lifecycle architecture or Task2 runner.
New TDD checks/focused qualification will precede applying it after root review;
the prior two architecture reviews are not repeated.

`context/linux_bootstrap.py` carries the explicit proposed controller bytes,
SHA256 `7955cf288687848a20dbd4aeb9538b16b617c4092ffd17b561aeeb6461420731`.
**Do not build this context against unchanged host source:** root must accept
the tiny patch, apply/test it on this qualification branch, and freeze the
resulting source/context hashes first. `proposed-source.json` records old/new
hashes for every file. No actual source file was modified at packet handoff.

## 4. Resource gates, identity and ownership

Actual fixed local Engine: `unix:///var/run/docker.sock`, ID
`d619836c-83fd-4b61-bccd-28f15d06069f`, 29.6.2/Linux x86_64/cgroup v2, exit0
(`engine-stage1.log/.exit`). Root's initial C free baseline was
103,356,309,504 B; this session recorded 103,346,520,064 B at intake. Latest
exact disk/context/artifact bytes are in `packet-audit.json`/`disk-phases.json`.
At this pre-build stage **new owned Docker images/containers/cache are 0 B**.

User ceiling: **5,000,000,000 B newly introduced temporary total**, retain
**at least 50,000,000,000 B C free**. Prefer a conservative **1 GiB planning
reservation**, not an assertion that unpacked image/cache size was measured.
Compressed layers are ~19.7 MiB; context is ~203 KiB. Unpacked/derived image
and builder-cache sizes remain unmeasured until approved materialization.
Expected peak is well below 5 GB; if measurement/projection exceeds the ceiling,
stop, preserve actual sizes and return to root. No automatic cloud purchase.

Record gates before/after each phase (source patch/context seal, digest pull,
build, image admission, each native witness group, exact owned cleanup): C free,
context/artifacts, exact new image IDs+Size, writable container/artifact usage,
and any attributable build-cache delta. Verify baseline preexisting image IDs
before pulling. Inspect `.Size` after pull and before build; stop if budget
reservation/free thresholds cannot be maintained. During pull/build monitor
free/introduced growth and cancel only the owned invocation if the ceiling is
approached; preserve incomplete evidence/residue for root inspection.

The observed existing global Docker usage (images240.9GB/cache46.39GB/etc) is
**not ours**; `docker-size-baseline.log` is read-only. No prune/delete/run of
factory/redis/node/unrelated images or containers occurred or is authorized.

Build with a fresh owned tag/nonce label, no daemon/context/settings change,
local endpoint/empty owned Docker config, `--network=none --no-cache` and only
the sealed context. No new builder service/image is proposed. Native profile
uses a new owned WSL ext4 fixture root, the actual immutable returned image ID,
and current non-root UID/GID (avoids changing borrowed environment/global state).
No host HOME/socket/secrets/network mounts enter an attempt.

Cleanup only exact witnessed attempt ID+nonce and exact new owned image IDs;
no-force image removal must refuse other references. Never remove a preexisting
base ID or any other alias/container. Default BuildKit can leave cache without
safe per-build deletion: record/budget that residue; **do not global-prune**.
This is temporary local evidence, not an installed long-term service.

## 5. Separate gates and requested root scope review

1. **Now:** root reviews official digest/provenance, full base disclosure,
   selected license/hash closure, concrete Dockerfile/curation, tiny bytecode
   patch and storage/owned cleanup boundaries. No runtime pull/build authority
   is inferred solely from Engine being started.
2. **After that review:** apply/test/seal only the tiny owned qualification
   corrections; pull exact digest within resource gate; measure base and build
   derived image offline. Verify image ID/rootfs/config, no volumes/unexpected
   env, every selected file/ELF dependency/license/controller byte and smoke
   imports/bytecode semantics. Failure stays nonzero/pending.
3. **Only after image admission:** run existing `qualify_linux_worker.py` native
   opt-in witnesses using WSL/read-only borrowed root9r8 interpreter, host
   `-B`+PYTHONDONTWRITEBYTECODE=1, no changes to that environment. Archive actual
   cgroups/exit/OOM/lifecycle and sibling evidence. Source/image admission is
   not cgroup/native qualification; mocked/skip evidence never passes this gate.

Current prerequisite-only invocation with no supplied qualified profile is
`pending/native_qualified=false`, **exit2** (`prerequisite-pending.log/.exit`
and `prerequisite-pending/qualification.json`). Its borrowed runtime is
`/var/tmp/quantmesh-portfolio-runtime-9r8rsnwz/venv/bin/python`, read-only.

Stop at Task1 native handoff. No Task2 runner/numerical/report/store/schema,
advisory/model effects, OpenD/helper/AWS/source/trading/GUI/CI/lock work is
included. Issue#172/local OCI software review still cannot certify AWS/server
delivery, full Linux research runtime or two-job <=90-second recovery.
