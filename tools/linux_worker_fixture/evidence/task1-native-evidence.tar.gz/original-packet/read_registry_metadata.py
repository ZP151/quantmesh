import hashlib,json,urllib.request,time,re,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
LIMIT=16*1024*1024

def fetch(url,headers=None):
 req=urllib.request.Request(url,headers=headers or {})
 with urllib.request.urlopen(req,timeout=30) as response:
  data=response.read(LIMIT+1)
  if len(data)>LIMIT: raise RuntimeError('metadata_size_limit')
  return data,dict(response.headers)

def save(name,data):
 (root/name).write_bytes(data)
 return 'sha256:'+hashlib.sha256(data).hexdigest()

library,_=fetch('https://raw.githubusercontent.com/docker-library/official-images/master/library/python')
save('official-python-library.txt',library)
blocks=library.decode().split('\n\n')
selected=next(b for b in blocks if re.search(r'^Tags: .*3\.12\.[0-9]+-alpine3\.23',b,re.M))
tag=re.search(r'^Tags: ([^,\n]+)',selected,re.M).group(1)
commit=re.search(r'^GitCommit: (\S+)',selected,re.M).group(1)
directory=re.search(r'^Directory: (\S+)',selected,re.M).group(1)
dockerfile_url=f'https://raw.githubusercontent.com/docker-library/python/{commit}/{directory}/Dockerfile'
dockerfile,_=fetch(dockerfile_url);dockerfile_sha=save('official-python-Dockerfile',dockerfile)
license_url=f'https://raw.githubusercontent.com/docker-library/python/{commit}/LICENSE'
license_bytes,_=fetch(license_url);license_sha=save('official-python-packaging-LICENSE',license_bytes)
token_body,_=fetch('https://auth.docker.io/token?service=registry.docker.io&scope=repository:library/python:pull')
token=json.loads(token_body)['token']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json'}
base='https://registry-1.docker.io/v2/library/python/'
index_data,index_headers=fetch(base+'manifests/'+tag,headers);index_digest=save('index.json',index_data)
index=json.loads(index_data)
chosen=next(m for m in index['manifests'] if m.get('platform')=={'architecture':'amd64','os':'linux'})
def descriptor(path,desc,name):
 data,meta=fetch(base+path+desc['digest'],headers)
 actual=save(name,data)
 if actual!=desc['digest'] or len(data)!=desc['size']: raise RuntimeError('descriptor_mismatch')
 return json.loads(data)
manifest=descriptor('manifests/',chosen,'amd64-manifest.json')
config=descriptor('blobs/',manifest['config'],'amd64-config.json')
attestations=[]
for i,m in enumerate(index['manifests']):
 if m.get('annotations',{}).get('vnd.docker.reference.digest')==chosen['digest']:
  am=descriptor('manifests/',m,f'attestation-{i}-manifest.json')
  for j,layer in enumerate(am['layers']):
   if layer['mediaType']=='application/vnd.in-toto+json':
    doc=descriptor('blobs/',layer,f'attestation-{i}-{j}.json')
    attestations.append({'file':f'attestation-{i}-{j}.json','digest':layer['digest'],'type':doc.get('predicateType')})
record={'tag':tag,'official_git_commit':commit,'official_directory':directory,'official_dockerfile_url':dockerfile_url,'official_dockerfile_sha256':dockerfile_sha,'packaging_license_url':license_url,'packaging_license_sha256':license_sha,'index_digest':index_digest,'index_header_digest':index_headers.get('Docker-Content-Digest'),'linux_amd64_manifest_digest':chosen['digest'],'image_config_digest':manifest['config']['digest'],'compressed_layer_bytes':sum(x['size'] for x in manifest['layers']),'layers':manifest['layers'],'image_env':config['config'].get('Env'),'image_volumes':config['config'].get('Volumes'),'attestations':attestations,'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'disk_free_bytes':shutil.disk_usage(root).free,'runtime_layers_downloaded':False}
(root/'registry-intake.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['tag','linux_amd64_manifest_digest','compressed_layer_bytes','image_env','image_volumes','attestations']}))
