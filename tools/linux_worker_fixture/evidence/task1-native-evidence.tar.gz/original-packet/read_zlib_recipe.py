import hashlib,json,re,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
url='https://api.github.com/repos/alpinelinux/aports/commits?sha=3.23-stable&path=main/zlib/APKBUILD&per_page=8'
with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'QuantMesh-owned-admission'}),timeout=30) as r: commits=json.load(r)
for entry in commits:
 commit=entry['sha'];url=f'https://raw.githubusercontent.com/alpinelinux/aports/{commit}/main/zlib/APKBUILD'
 with urllib.request.urlopen(url,timeout=30) as r:data=r.read(512*1024)
 text=data.decode()
 if re.search(r'^pkgver=1\.3\.2$',text,re.M) and re.search(r'^pkgrel=0$',text,re.M):
  (root/'zlib-r0-APKBUILD').write_bytes(data)
  result=dict(package='zlib',version='1.3.2-r0',commit=commit,url=url,sha256=hashlib.sha256(data).hexdigest(),current_r1_recipe_not_used=True)
  (root/'zlib-r0-intake.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result));break
else: raise RuntimeError('exact_zlib_recipe_unavailable')
