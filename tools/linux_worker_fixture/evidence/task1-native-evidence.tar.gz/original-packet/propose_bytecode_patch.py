import difflib,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
patch=[]
changes={}
for relative in ['src/quantmesh/research/linux_owned.py','src/quantmesh/research/linux_bootstrap.py','tools/qualify_linux_worker.py']:
 source=Path(relative).read_text(); proposed=source
 if relative.endswith('linux_owned.py'):
  assert source.count('                        "LC_ALL",')==1
  proposed=proposed.replace('                        "LC_ALL",','                        "LC_ALL",\n                        "PYTHONDONTWRITEBYTECODE",')
  assert source.count('            profile.image_id,\n            "-I",')==1
  proposed=proposed.replace('            profile.image_id,\n            "-I",','            profile.image_id,\n            "-B",\n            "-I",')
 elif relative.endswith('linux_bootstrap.py'):
  assert source.count('env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},')==1
  proposed=proposed.replace('env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"},',
   'env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8",\n                     "PYTHONDONTWRITEBYTECODE": "1"},')
 else:
  proposed=proposed.replace('[PYTHON_PATH, "-c",','[PYTHON_PATH, "-B", "-c",')
  proposed=proposed.replace("[sys.executable,'-c',","[sys.executable,'-B','-c',")
  proposed=proposed.replace('                sys.executable,\n                str(Path(__file__).resolve()),',
                            '                sys.executable,\n                "-B",\n                str(Path(__file__).resolve()),')
  proposed=proposed.replace("{'PATH','LANG','LC_CTYPE'}","{'PATH','LANG','LC_CTYPE','PYTHONDONTWRITEBYTECODE'}")
  proposed=proposed.replace("assert os.getuid()!=0","assert os.getuid()!=0\nassert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'\nimport sys\nassert sys.dont_write_bytecode")
 assert source!=proposed,relative
 patch.extend(difflib.unified_diff(source.splitlines(True),proposed.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 target=root/'proposed-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(proposed,newline='\n')
 changes[relative]={'current_sha256':hashlib.sha256(Path(relative).read_bytes()).hexdigest(),'proposed_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(root/'bytecode-only-proposal.patch').write_text(''.join(patch),newline='\n')
(root/'proposed-source.json').write_text(json.dumps(changes,indent=2)+'\n')
# Source bytes are currently unchanged. Context carries the explicit proposed
# controller bytes; build/admission requires applying this reviewed tiny patch.
context=root/'context'/'linux_bootstrap.py'
context.write_bytes((root/'proposed-source/src/quantmesh/research/linux_bootstrap.py').read_bytes())
print(json.dumps(changes,indent=2))
