import datetime,json,os,shutil,subprocess,time,re,decimal
from pathlib import Path
PHASE=Path('/mnt/c/Users/15492/.codex-clean/worktrees/a718/QuantMesh/output/172-native-qualified-20261013')
STATE=json.loads((PHASE/'native-state.json').read_text())
ROOT=Path(STATE['native_root'])
ARGV=[STATE['docker_cli'],'--host',STATE['engine'],'--config',STATE['docker_config']]
ENV={'PATH':'/usr/bin:/bin:/usr/local/bin','PYTHONDONTWRITEBYTECODE':'1'}
BASE_ID='sha256:9ce5a4e59b833c002e1c4196c60ec0b38977e3235d626298ba7ffe2e64f5a30c'

def size(root):
 return sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
def capture(args,name,timeout=60):
 r=subprocess.run(ARGV+args,env=ENV,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
 (PHASE/(name+'.stdout')).write_bytes(r.stdout);(PHASE/(name+'.stderr')).write_bytes(r.stderr);(PHASE/(name+'.exit')).write_text(str(r.returncode)+'\n')
 if r.returncode:raise RuntimeError(name+'_failed')
 return r.stdout.decode()
def cache_records(text):
 return [json.loads(line) for line in text.splitlines() if line.strip()]
def display_upper(value):
 if isinstance(value,int):return value
 match=re.fullmatch(r'([0-9.]+)(B|kB|MB|GB|TB)',value)
 if not match:raise RuntimeError('unknown_cache_size_display')
 scale={'B':1,'kB':1000,'MB':1000000,'GB':1000000000,'TB':1000000000000}[match[2]]
 number=decimal.Decimal(match[1]);quantum=decimal.Decimal(1).scaleb(number.as_tuple().exponent)
 return int((number+quantum)*scale)
def checkpoint(name,images=()):
 records=cache_records(capture(['buildx','du','--format=json'],'cache-'+name,90))
 baseline={x['ID'] for x in cache_records((PHASE/'cache-baseline.json').read_text())}
 new=[x for x in records if x['ID'] not in baseline]
 cache_bytes=sum(display_upper(x.get('Size',0)) for x in new)
 docs=[]
 for image in images:
  docs.append(json.loads(capture(['image','inspect',image],'image-'+name+'-'+image[-12:]))[0])
 image_bytes=sum(x['Size'] for x in docs)
 root_bytes=size(ROOT);artifact_bytes=size(PHASE);free=shutil.disk_usage('/mnt/c').free
 logical=root_bytes+artifact_bytes+image_bytes+cache_bytes
 c_delta=max(0,STATE['free_c_start']-free)
 total=max(logical,c_delta)
 record=dict(phase=name,utc=datetime.datetime.now(datetime.UTC).isoformat(),free_c_bytes=free,owned_root_bytes=root_bytes,artifact_bytes=artifact_bytes,new_image_bytes=image_bytes,image_size_semantics='Engine-reported Size; not claimed unpacked/physical allocation',new_image_ids=[d['Id'] for d in docs],new_cache_bytes_upper_bound=cache_bytes,new_cache_size_display=[{'id':x['ID'],'Size':x['Size']} for x in new],new_cache_ids=[x['ID'] for x in new],new_cache_attribution='conservative-new-records-since-own-baseline; CLI rounded display upper bounds; never-pruned',introduced_total_conservative_bytes=total,c_free_delta_conservative_bytes=c_delta,limits=dict(total=5000000000,free_floor=50000000000),actual_image_size_measured=bool(docs))
 (PHASE/('disk-'+name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 if free<50000000000 or total>5000000000:raise RuntimeError('resource_gate_failed')
 return record

def owned_operation(args,name,timeout=180):
 before=checkpoint(name+'-before')
 stdout=(PHASE/(name+'.stdout')).open('wb');stderr=(PHASE/(name+'.stderr')).open('wb')
 process=subprocess.Popen(ARGV+args,env=ENV,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
 started=time.monotonic();measurements=[]
 try:
  while process.poll() is None:
   free=shutil.disk_usage('/mnt/c').free;delta=max(0,STATE['free_c_start']-free)
   measurements.append(dict(elapsed=time.monotonic()-started,free_c_bytes=free,c_free_delta_bytes=delta))
   if free<50000000000 or delta>5000000000 or time.monotonic()-started>timeout:
    process.kill();process.wait(timeout=10);raise RuntimeError('owned_operation_budget_or_timeout_stop')
   time.sleep(1)
  code=process.returncode
  (PHASE/(name+'.exit')).write_text(str(code)+'\n')
  if code:raise RuntimeError(name+'_failed')
 finally:
  stdout.close();stderr.close()
  (PHASE/(name+'-disk-watch.json')).write_text(json.dumps(measurements,indent=2)+'\n')
 return code

if __name__=='__main__':
 # Resume after successful pull; do not duplicate materialization or old evidence.
 assert (PHASE/'digest-pull.exit').read_text().strip()=='0'
 base=json.loads(capture(['image','inspect',BASE_ID],'base-actual'))[0]
 assert base['Id']==BASE_ID and base['Os']=='linux' and base['Architecture']=='amd64'
 expected=json.loads((PHASE.parent/'172-native-admission/amd64-config.json').read_text())
 assert base['Config']['Env']==expected['config']['Env']
 assert base['RootFS']['Layers']==expected['rootfs']['diff_ids']
 STATE['preexisting_base']=BASE_ID in json.loads((PHASE/'images-baseline.json').read_text())
 STATE['base_actual_id']=BASE_ID
 STATE['base_config_digest']='sha256:56d444819cc60d5188b3e0d64396cf76a0b3e64a952836cb3155f6dc5a7e80b9'
 (PHASE/'native-state.json').write_text(json.dumps(STATE,indent=2)+'\n')
 (PHASE/'base-actual.json').write_text(json.dumps(base,indent=2)+'\n')
 record=checkpoint('base-pulled',[BASE_ID] if not STATE['preexisting_base'] else [])
 print(json.dumps(dict(base_image_id=base['Id'],base_actual_size_bytes=base['Size'],free_c_bytes=record['free_c_bytes'],introduced_total_bytes=record['introduced_total_conservative_bytes'])))
