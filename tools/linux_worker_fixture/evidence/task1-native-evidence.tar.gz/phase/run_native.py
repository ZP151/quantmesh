import json,subprocess,sys,time,shutil,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import STATE,ROOT,PHASE,BASE_ID,ENV,checkpoint,size
admission=json.loads((PHASE/'image-admission-final.json').read_text())
assert admission['image_admitted'] and admission['smoke_passed']
checkpoint('native-before',[BASE_ID,STATE['derived_id']])
output=ROOT/'fixtures/native-run1'
args=[sys.executable,'-B',str(ROOT/'source/tools/qualify_linux_worker.py'),'--profile',str(ROOT/'profile.json'),'--output',str(output),'--native-fixtures']
env=dict(ENV,PYTHONPATH=str(ROOT/'source/src'))
stdout=(PHASE/'native-run1.stdout').open('wb');stderr=(PHASE/'native-run1.stderr').open('wb')
process=subprocess.Popen(args,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
started=time.monotonic();samples=[]
try:
 while process.poll() is None:
  free=shutil.disk_usage('/mnt/c').free;root_bytes=size(ROOT);art_bytes=size(PHASE)
  # Previously measured image/cache already reserved; CLI-rounded cache bound.
  before=json.loads((PHASE/'disk-native-before.json').read_text())
  logical=root_bytes+art_bytes+before['new_image_bytes']+before['new_cache_bytes_upper_bound']
  total=max(logical,max(0,STATE['free_c_start']-free))
  samples.append(dict(elapsed_seconds=time.monotonic()-started,free_c_bytes=free,owned_root_bytes=root_bytes,artifact_bytes=art_bytes,introduced_total_conservative_bytes=total))
  if free<50000000000 or total>5000000000 or time.monotonic()-started>180:
   process.kill();process.wait(timeout=10);raise RuntimeError('native_resource_or_timeout_stop')
  time.sleep(1)
 code=process.returncode
 (PHASE/'native-run1.exit').write_text(str(code)+'\n')
finally:
 stdout.close();stderr.close()
 (PHASE/'native-run1-disk-watch.json').write_text(json.dumps(samples,indent=2)+'\n')
if (output/'qualification.json').exists():
 result=json.loads((output/'qualification.json').read_text());(PHASE/'native-run1-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
else:raise RuntimeError('native_result_missing')
checkpoint('native-after',[BASE_ID,STATE['derived_id']])
print(json.dumps(dict(exit=code,status=result['status'],qualified=result['native_qualified'],reason=result.get('reason'),checks={k:v.get('passed') for k,v in result['checks'].items()},elapsed_seconds=time.monotonic()-started)))
