import hashlib,json,struct,tarfile,io,time,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import STATE,ROOT,PHASE,BASE_ID,capture,checkpoint
image=json.loads((PHASE/'derived-actual.json').read_text())
assert image['Config'].get('Volumes') is None
assert set(image['Config']['Env'])=={'PATH=/usr/local/bin','LANG=C.UTF-8','PYTHONDONTWRITEBYTECODE=1'}
assert image['Config']['Entrypoint']==['/usr/local/bin/python3','-B','-I','/opt/quantmesh/linux_bootstrap.py']
assert image['Config']['User']=='10001:10001'
assert image['Config']['Labels']['org.quantmesh.fixture.owner']==STATE['nonce']
label='org.quantmesh.fixture.inspection'
container=capture(['create','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--pids-limit=128','--memory=128m','--memory-swap=128m','--cpus=1','--user',str(STATE['uid'])+':'+str(STATE['gid']),'--label',label+'='+STATE['nonce'],'--entrypoint','/usr/local/bin/python3',STATE['derived_id'],'-B','-c','pass'],'admission2-create').strip()
(PHASE/'admission2-container-id.txt').write_text(container+'\n')
def inspect_owned():
 doc=json.loads(capture(['inspect',container],'admission2-container-inspect'))[0]
 assert doc['Id']==container and doc['Image']==STATE['derived_id']
 assert doc['Config']['Labels'][label]==STATE['nonce']
 assert doc['State']['Running'] is False
 return doc
inspect_owned()
try:
 archive=ROOT/'image-rootfs2.tar'
 capture(['export','--output',str(archive),container],'admission2-export',120)
 with tarfile.open(archive,'r:') as tar:
  members={m.name.removeprefix('./').lstrip('/'):m for m in tar.getmembers()}
  manifest_bytes=tar.extractfile(members['opt/quantmesh/runtime-files.json']).read()
  manifest=json.loads(manifest_bytes)
  source=(ROOT/'source/src/quantmesh/research/linux_bootstrap.py').read_bytes()
  assert manifest['bootstrap_sha256']==hashlib.sha256(source).hexdigest()
  expected_names=set()
  for item in manifest['files']:
   name=item['path'];expected_names.add(name);m=members[name]
   if 'symlink' in item:
    assert m.issym() and m.linkname==item['symlink']
   else:
    assert m.isfile() and m.size==item['bytes']
    data=tar.extractfile(m).read()
    assert hashlib.sha256(data).hexdigest()==item['sha256'],name
  extra=[name for name,m in members.items() if m.isfile() and name not in expected_names]
  engine_placeholders={'.dockerenv','dev/console','etc/hosts','etc/hostname','etc/resolv.conf'}
  assert set(extra)<={'opt/quantmesh/runtime-files.json'}|engine_placeholders,extra
  for name in engine_placeholders:
   if name in members:assert members[name].size==0
  assert all(not n.startswith(('bin/','sbin/','root/','usr/lib/apk','usr/local/lib/python3.12/site-packages','usr/local/lib/python3.12/ensurepip')) for n in members)
  allowed={'libpython3.12.so.1.0','libc.musl-x86_64.so.1','libcrypto.so.3'}
  observed={}
  for name,m in members.items():
   if not m.isfile():continue
   data=tar.extractfile(m).read()
   if not data.startswith(b'\x7fELF'):continue
   assert data[4:6]==b'\x02\x01'
   h=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
   assert h[2]==62
   ph=[struct.unpack_from('<IIQQQQQQ',data,h[5]+i*h[9]) for i in range(h[10])]
   for seg in ph:
    if seg[0]==3:assert data[seg[2]:seg[2]+seg[5]].rstrip(b'\0')==b'/lib/ld-musl-x86_64.so.1'
   dynamic=next((x for x in ph if x[0]==2),None)
   needed=set()
   if dynamic:
    table=[]
    for pos in range(dynamic[2],dynamic[2]+dynamic[5],16):
     tag,val=struct.unpack_from('<qQ',data,pos)
     if tag==0:break
     table.append((tag,val))
    address=next(v for t,v in table if t==5)
    load=next(x for x in ph if x[0]==1 and x[3]<=address<x[3]+x[5])
    start=load[2]+address-load[3]
    for tag,val in table:
     if tag==1:
      begin=start+val;needed.add(data[begin:data.index(b'\0',begin)].decode())
   assert needed<=allowed,(name,needed)
   observed[name]=sorted(needed)
  assert len(observed)==26
  for item in (ROOT/'context/licenses').iterdir():
   data=tar.extractfile(members['opt/quantmesh/licenses/'+item.name]).read()
   assert data==item.read_bytes()
  (PHASE/'runtime-files-actual.json').write_bytes(manifest_bytes)
  result=dict(scope='TASK1_STDLIB_FIXTURE_IMAGE_ONLY',image_id=STATE['derived_id'],engine_image_Size=image['Size'],rootfs_tar_bytes=archive.stat().st_size,selected_regular_file_bytes=sum(x.get('bytes',0) for x in manifest['files']),file_count=len(manifest['files']),elf_files=len(observed),elf_dependencies=observed,all_file_hashes_verified=True,license_bytes_verified=True,unexpected_env=False,volumes=False,bootstrap_sha256=manifest['bootstrap_sha256'],filesystem_admitted=True,smoke_passed=False,native_qualified=False)
  (PHASE/'image-filesystem-admission.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 inspect_owned()
 capture(['rm',container],'admission2-remove')
checkpoint('filesystem-admitted',[BASE_ID,STATE['derived_id']])
print(json.dumps({k:result[k] for k in ['image_id','rootfs_tar_bytes','selected_regular_file_bytes','file_count','elf_files','all_file_hashes_verified']}))
