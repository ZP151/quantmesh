import json, subprocess, sys, datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from materialize import STATE, ROOT, PHASE, ARGV, ENV, BASE_ID, capture, checkpoint
assert sys.dont_write_bytecode
assert ENV['PYTHONDONTWRITEBYTECODE'] == '1'
assert json.loads((ROOT/'ownership.json').read_text())['nonce'] == STATE['nonce']
engine = capture(['info','--format','{{.ID}}'], 'cleanup-engine-id').strip()
assert engine == 'd619836c-83fd-4b61-bccd-28f15d06069f'
baseline = [json.loads(line) for line in (PHASE/'containers-baseline.stdout').read_text().splitlines() if line.strip()]
before = capture(['ps','-a','--no-trunc','--format','{{.ID}}|{{.State}}'], 'cleanup-containers-before')
observed = dict(line.split('|',1) for line in before.splitlines() if line.strip())
baseline_safe = {row['ID']:row['State'] for row in baseline}
assert all(observed.get(key) == state for key,state in baseline_safe.items())
known = set()
def visit(node):
 if isinstance(node, dict):
  for key,value in node.items():
   if key == 'container_id' and isinstance(value,str): known.add(value)
   else: visit(value)
 elif isinstance(node,list):
  for value in node:visit(value)
for root in [PHASE,ROOT/'fixtures']:
 for path in root.rglob('*.json'):
  if path.stat().st_size < 200000:
   try:visit(json.loads(path.read_text()))
   except (ValueError,UnicodeError):pass
for name in ['admission-container-id.txt','admission2-container-id.txt']:
 known.add((PHASE/name).read_text().strip())
visit(json.loads((ROOT/'smoke-identity.json').read_text()))
assert not known.intersection(observed)
new_ids = sorted(set(observed)-set(baseline_safe))
# Only baseline states and our witnessed IDs are retained, no unrelated commands/env.
(PHASE/'container-cleanup-witness.json').write_text(json.dumps(dict(baseline_states=baseline_safe,all_baseline_states_preserved=True,known_owned_ids=sorted(known),known_owned_ids_absent=True,other_new_container_ids=new_ids),indent=2)+'\n')
images_baseline=set(json.loads((PHASE/'images-baseline.json').read_text()))
cleanup=[]
for image in [STATE['derived_id'],BASE_ID]:
 assert image not in images_baseline
 doc=json.loads(capture(['image','inspect',image], 'cleanup-inspect-'+image[-12:]))[0]
 assert doc['Id']==image
 if image==STATE['derived_id']:
  assert doc['Config']['Labels']['org.quantmesh.fixture.owner']==STATE['nonce']
  assert doc['Config']['Labels']['org.quantmesh.fixture.scope']=='task1-stdlib-only'
  assert doc['RepoTags']==[STATE['derived_tag']]
  assert doc['RepoDigests']==[STATE['derived_tag'].split(':')[0]+'@'+image]
 else:
  assert not doc.get('RepoTags')
  assert doc['RepoDigests']==['python@'+image]
 refs=capture(['ps','-a','--no-trunc','--filter','ancestor='+image,'--format','{{.ID}}'], 'cleanup-references-'+image[-12:])
 assert not refs.strip()
 output=capture(['image','rm',image], 'cleanup-image-'+image[-12:])
 after=subprocess.run(ARGV+['image','inspect',image],env=ENV,stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
 (PHASE/('cleanup-absent-'+image[-12:]+'.stdout')).write_bytes(after.stdout)
 (PHASE/('cleanup-absent-'+image[-12:]+'.stderr')).write_bytes(after.stderr)
 (PHASE/('cleanup-absent-'+image[-12:]+'.exit')).write_text(str(after.returncode)+'\n')
 assert after.returncode != 0 and not after.stdout.strip(b' \n\t[]')
 cleanup.append(dict(image_id=image,baseline_absent=True,nonce_verified=image==STATE['derived_id'],no_container_reference=True,no_force=True,removed=True))
after=capture(['ps','-a','--no-trunc','--format','{{.ID}}|{{.State}}'],'cleanup-containers-after')
assert after==before
report=dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),engine_id=engine,images=cleanup,container_states_unchanged=True,known_owned_ids_absent=True,cache_policy='retain new measured record IDs; no precise safe per-build deletion available; no prune',borrowed_runtime_policy='read-only; Python -B and PYTHONDONTWRITEBYTECODE=1; no packages modified')
(PHASE/'cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
disk=checkpoint('cleanup-final')
print(json.dumps(dict(images_removed=len(cleanup),owned_containers_remaining=0,free_c_bytes=disk['free_c_bytes'],introduced_total_conservative_bytes=disk['introduced_total_conservative_bytes'],retained_cache_upper_bound_bytes=disk['new_cache_bytes_upper_bound'])))
