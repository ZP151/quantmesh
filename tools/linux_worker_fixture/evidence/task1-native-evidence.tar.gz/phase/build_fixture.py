import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import STATE,ROOT,PHASE,BASE_ID,capture,checkpoint,owned_operation
for item in json.loads((PHASE/'context-seal-phase1.json').read_text()):
 p=ROOT/'context'/item['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
tag='quantmesh-task1-native:'+STATE['nonce']
iid=ROOT/'image-id.txt'
args=['build','--platform=linux/amd64','--network=none','--no-cache','--provenance=false','--progress=plain','--iidfile',str(iid),'--label','org.quantmesh.fixture.owner='+STATE['nonce'],'--label','org.quantmesh.fixture.scope=task1-stdlib-only','-t',tag,str(ROOT/'context')]
owned_operation(args,'fixture-build',timeout=180)
image=json.loads(capture(['image','inspect',tag],'derived-actual'))[0]
STATE.update(derived_id=image['Id'],derived_tag=tag)
(PHASE/'native-state.json').write_text(json.dumps(STATE,indent=2)+'\n')
(PHASE/'derived-actual.json').write_text(json.dumps(image,indent=2)+'\n')
assert image['Id'] not in json.loads((PHASE/'images-baseline.json').read_text())
assert image['Config']['Labels']['org.quantmesh.fixture.owner']==STATE['nonce']
record=checkpoint('image-built',[BASE_ID,image['Id']])
print(json.dumps(dict(image_id=image['Id'],Size=image['Size'],free_c_bytes=record['free_c_bytes'],introduced_bytes=record['introduced_total_conservative_bytes'])))
