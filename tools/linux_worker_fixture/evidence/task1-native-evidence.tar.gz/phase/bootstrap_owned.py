import json,os,subprocess,shutil,hashlib,time,datetime
from pathlib import Path
PHASE=Path('/mnt/c/Users/15492/.codex-clean/worktrees/a718/QuantMesh/output/172-native-qualified-20261013')
OWN=json.loads((PHASE/'ownership.json').read_text())
ROOT=Path(OWN['native_root']);ROOT.mkdir(exist_ok=False)
(ROOT/'ownership.json').write_text(json.dumps(OWN,indent=2)+'\n')
CONFIG=ROOT/'docker-empty';CONFIG.mkdir()
CLI=Path('/usr/bin/docker').resolve(strict=True)
ENV={'PATH':'/usr/bin:/bin:/usr/local/bin','PYTHONDONTWRITEBYTECODE':'1'}
argv=[str(CLI),'--host',OWN['engine'],'--config',str(CONFIG)]
def run(args,name,timeout=60):
 result=subprocess.run(args,env=ENV,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
 (PHASE/(name+'.stdout')).write_bytes(result.stdout);(PHASE/(name+'.stderr')).write_bytes(result.stderr)
 (PHASE/(name+'.exit')).write_text(str(result.returncode)+'\n')
 if result.returncode:raise RuntimeError(name+'_failed')
 return result.stdout.decode()
info=json.loads(run(argv+['info','--format','{{json .}}'],'engine-baseline'))
assert info['ID']=='d619836c-83fd-4b61-bccd-28f15d06069f' and info['CgroupVersion']=='2'
images=sorted(set(run(argv+['image','ls','--quiet','--no-trunc'],'images-baseline').splitlines()))
( PHASE/'images-baseline.json').write_text(json.dumps(images,indent=2)+'\n')
cache=run(argv+['buildx','du','--format=json'],'cache-baseline',timeout=90)
( PHASE/'cache-baseline.json').write_text(cache)
containers=run(argv+['ps','-a','--no-trunc','--format','{{json .}}'],'containers-baseline')
free=shutil.disk_usage('/mnt/c').free
assert free>=50000000000
state=dict(OWN,docker_cli=str(CLI),docker_config=str(CONFIG),uid=os.getuid(),gid=os.getgid(),free_c_start=free,preexisting_base= 'sha256:56d444819cc60d5188b3e0d64396cf76a0b3e64a952836cb3155f6dc5a7e80b9' in images,stage='baseline')
( PHASE/'native-state.json').write_text(json.dumps(state,indent=2)+'\n')
repo=ROOT/'source'
run(['/usr/bin/git','-c','core.autocrlf=false','-c','core.hooksPath=/dev/null','clone','--no-hardlinks','--depth','1','--branch','codex/0038-linux-native-qualification','file:///mnt/c/Users/15492/Develop/QuantMesh',str(repo)],'native-clone',timeout=180)
for rel in ['src/quantmesh/research/linux_owned.py','src/quantmesh/research/linux_bootstrap.py','tools/qualify_linux_worker.py','tests/test_linux_owned.py']:
 source=PHASE.parents[1]/rel;target=repo/rel
 target.write_bytes(source.read_bytes())
context=ROOT/'context';shutil.copytree(PHASE/'context',context)
bytes_root=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
bytes_phase=sum(p.stat().st_size for p in PHASE.rglob('*') if p.is_file())
free=shutil.disk_usage('/mnt/c').free
assert bytes_root+bytes_phase<5000000000 and free>=50000000000
record=dict(phase='owned_clone_context',free_c_bytes=free,owned_root_bytes=bytes_root,artifacts_bytes=bytes_phase,owned_image_bytes=0,owned_container_writable_bytes=0,owned_cache_bytes=0,estimated_reservation_bytes=1073741824,estimated_not_measured=True,utc=datetime.datetime.now(datetime.UTC).isoformat())
( PHASE/'disk-clone-context.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native_root=str(ROOT),docker_cli=str(CLI),preexisting_base=state['preexisting_base'],root_bytes=bytes_root,free_c_bytes=free)))
