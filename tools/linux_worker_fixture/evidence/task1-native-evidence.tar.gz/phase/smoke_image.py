import json,sys,time,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import STATE,ROOT,PHASE,BASE_ID,checkpoint
sys.path.insert(0,str(ROOT/'source/src'))
from quantmesh.research.linux_owned import LinuxExecutionProfile,LinuxOwnedProcess,PYTHON_PATH
from quantmesh.research.jobs import RunBudget
fixture=ROOT/'fixtures';fixture.mkdir()
profile=LinuxExecutionProfile(endpoint=STATE['engine'],docker_cli=Path(STATE['docker_cli']),image_id=STATE['derived_id'],uid=STATE['uid'],gid=STATE['gid'],fixture_root=fixture)
profile_doc=dict(endpoint=profile.endpoint,docker_cli=str(profile.docker_cli),image_id=profile.image_id,uid=profile.uid,gid=profile.gid,fixture_root=str(profile.fixture_root))
(ROOT/'profile.json').write_text(json.dumps(profile_doc,indent=2)+'\n')
(PHASE/'profile.json').write_text(json.dumps(profile_doc,indent=2)+'\n')
inputs=fixture/'smoke-inputs';inputs.mkdir();(inputs/'fixture.txt').write_text('immutable\n')
script="""
import json,hashlib,subprocess,signal,selectors,socket,resource,os,sys,time,math,struct
from pathlib import Path
assert sys.dont_write_bytecode and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
assert hashlib.sha256(b'fixture').hexdigest()=='f16d05ec6b29248d2c61adb8f8e9263f78e4f7f460d4723cd81c7b2a8e6b7de30'
r=subprocess.run([sys.executable,'-B','-c',"import os,sys;assert sys.dont_write_bytecode;assert os.environ['PYTHONDONTWRITEBYTECODE']=='1'"],check=True,stdin=subprocess.DEVNULL)
print(json.dumps(dict(python=sys.version,executable=sys.executable,uid=os.getuid(),gid=os.getgid(),dont_write_bytecode=sys.dont_write_bytecode,environment=sorted(os.environ),kernel=os.uname().release,limits={k:Path('/sys/fs/cgroup/'+k).read_text().strip() for k in ['memory.max','memory.swap.max','cpu.max','pids.max']},bootstrap_sha256=hashlib.sha256(Path('/opt/quantmesh/linux_bootstrap.py').read_bytes()).hexdigest())))
"""
# The actual expected hash is computed from the same literal input, not invented.
script=script.replace('f16d05ec6b29248d2c61adb8f8e9263f78e4f7f460d4723cd81c7b2a8e6b7de30',hashlib.sha256(b'fixture').hexdigest())
worker=LinuxOwnedProcess(profile,[PYTHON_PATH,'-B','-c',script],RunBudget(memory_mib=128,timeout_seconds=20),inputs,fixture/'smoke-attempt')
(ROOT/'smoke-identity.json').write_text(json.dumps(dict(id=worker.container_id,nonce=worker.nonce))+'\n')
try:
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  code=worker.poll()
  if code is not None:break
  worker.pulse();time.sleep(.5)
 else:raise RuntimeError('smoke_timeout')
 result=dict(worker.evidence,actual_exit=code)
 (PHASE/'smoke-process.json').write_text(json.dumps(result,indent=2)+'\n')
 stdout=(worker.output/'stdout.log').read_text();stderr=(worker.output/'stderr.log').read_text()
 (PHASE/'smoke.stdout').write_text(stdout);(PHASE/'smoke.stderr').write_text(stderr)
 if code!=0:raise RuntimeError('smoke_nonzero')
 measured=json.loads(stdout)
 assert measured['bootstrap_sha256']==hashlib.sha256((ROOT/'source/src/quantmesh/research/linux_bootstrap.py').read_bytes()).hexdigest()
 (PHASE/'smoke-result.json').write_text(json.dumps(measured,indent=2)+'\n')
finally:
 worker.close()
record=checkpoint('smoke-admitted',[BASE_ID,STATE['derived_id']])
admission=json.loads((PHASE/'image-filesystem-admission.json').read_text());admission.update(smoke_passed=True,image_admitted=True)
(PHASE/'image-admission-final.json').write_text(json.dumps(admission,indent=2)+'\n')
print(json.dumps(dict(image_admitted=True,scope=admission['scope'],cgroups=measured['limits'],actual_exit=code,free_c_bytes=record['free_c_bytes'],introduced_bytes=record['introduced_total_conservative_bytes'])))
