import gzip,hashlib,io,json,os,sys,tarfile,datetime,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import PHASE,ROOT,STATE,size
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
repo=PHASE.parents[1]
output=repo/'tools/linux_worker_fixture/evidence'
assert not output.exists()
items={}
def include(path,name):
 assert path.is_file() and not path.is_symlink()
 assert name not in items and not name.startswith('/') and '..' not in Path(name).parts
 items[name]=path
# Exclude all unrelated Engine/image/container/cache inventories and test temp dirs.
for p in sorted(PHASE.iterdir()):
 if not p.is_file():continue
 if p.name.startswith(('cache-','images-baseline','containers-baseline','engine-baseline','native-clone')):continue
 if p.suffix in {'.json','.log','.exit','.stdout','.stderr','.py','.txt'}:include(p,'phase/'+p.name)
for p in sorted((PHASE.parent/'172-native-admission').iterdir()):
 if p.is_file() and not p.name.startswith('docker-size-baseline'):
  include(p,'original-packet/'+p.name)
for entry in json.loads((PHASE/'source-seal-phase1.json').read_text()):
 p=ROOT/'source'/entry['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
 include(p,'tested-source/'+entry['path'])
for entry in json.loads((PHASE/'context-seal-phase1.json').read_text()):
 p=ROOT/'context'/entry['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
 include(p,'executed-context/'+entry['path'])
for p in sorted((ROOT/'fixtures').rglob('*')):
 if p.is_file() and '.empty-docker-config' not in p.parts:
  assert p.suffix not in {'.pyc','.pyo'}
  include(p,'native-fixtures/'+p.relative_to(ROOT/'fixtures').as_posix())
include(ROOT/'profile.json','native-profile.json')
include(ROOT/'smoke-identity.json','smoke-identity.json')
include(Path('/mnt/c/Users/15492/.codex-clean/worktrees/0038-research-integration/QuantMesh/output/0038-linux-native-admission/root-packet-review.json'),'root-packet-review.json')
manifest=[dict(path=n,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in sorted(items.items())]
large=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retained_in_place=True) for p in [ROOT/'image-rootfs.tar',ROOT/'image-rootfs2.tar']]
internal=json.dumps(dict(scope='Task1 stdlib fixture only',files=manifest,large_rootfs_archives=large,privacy_exclusions=['unrelated baseline Engine/config/image/container/cache payloads'],resource_status='native run passed; post-cleanup conservative whole-volume delta failed; attribution unproven'),indent=2).encode()
stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for name,p in sorted(items.items()):
   data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
   tar.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('MANIFEST.json');info.size=len(internal);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(internal))
blob=stream.getvalue()
assert len(blob)<=2000000, 'bounded_metadata_archive_exceeds_two_MB_stop'
# Read back every member before writing; no extraction into borrowed/global paths.
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as tar:
 expected={x['path']:x for x in manifest}
 assert len(tar.getmembers())==len(expected)+1
 for member in tar:
  data=tar.extractfile(member).read()
  if member.name=='MANIFEST.json':assert data==internal
  else:assert hashlib.sha256(data).hexdigest()==expected[member.name]['sha256']
output.mkdir()
archive=output/'task1-native-evidence.tar.gz';archive.write_bytes(blob)
index=dict(schema_version=1,scope='Task1 stdlib fixture native OCI only',source_base=STATE['source'],source_branch='codex/0038-linux-native-qualification',archive=archive.name,archive_bytes=len(blob),archive_sha256=hashlib.sha256(blob).hexdigest(),archive_members=len(manifest)+1,manifest_sha256=hashlib.sha256(internal).hexdigest(),raw_archive_contents='original reviewed public packet; exact executed context; four tested source files; native fixture inputs/outputs; phase logs; approval; narrow review; cleanup failures and success',rootfs_archives_retained_in_place=large,engine_id='d619836c-83fd-4b61-bccd-28f15d06069f',image_id=STATE['derived_id'],image_config_digest='sha256:2bbe620f62bed9f37df4cc76f65105cfdbbe90eefa4c7cb5a964c2dcc424d250',bootstrap_sha256='e05ce046cd800ab801e4ceafb352c02de20774dc2f9bf92dc77ed3688f6de740',native_qualified=True,native_required_passed=15,focused_regression=dict(passed=48,deselected=23,warnings=1,seconds=16.41),cleanup=dict(images_removed=2,known_owned_containers_remaining=0,baseline_states_preserved=True,cache_new_records=12,cache_cli_display_upper_bound_bytes=83875867,no_global_prune=True),resource_status=dict(native_run_conservative_bytes=547016704,native_run_free_c_bytes=102358667264,post_cleanup_gate='failed',post_cleanup_free_c_bytes=89973710848,post_cleanup_c_free_delta_bytes=12931973120,post_cleanup_attributable_logical_bytes=203031020,extra_whole_volume_delta_attribution='unproven',archive_maximum_bytes=2000000),remaining=['storage attribution/final acceptance','Task2 numerical Worker image/integration','two-job/reclaim equivalence','server/AWS release gates'])
(output/'index.json').write_text(json.dumps(index,indent=2)+'\n')
(PHASE/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
free=shutil.disk_usage('/mnt/c').free
(PHASE/'disk-metadata-after.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),free_c_bytes=free,c_free_delta_bytes=max(0,STATE['free_c_start']-free),owned_root_bytes=size(ROOT),phase_bytes=size(PHASE),metadata_archive_bytes=len(blob),new_cache_cli_display_upper_bound_bytes=83875867,resource_status='post-cleanup conservative gate failed; no new image materialization'),indent=2)+'\n')
print(json.dumps(dict(archive_bytes=len(blob),archive_sha256=index['archive_sha256'],members=index['archive_members'],large_archives_copied=False,free_c_bytes=free)))
