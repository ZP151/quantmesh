import json,tarfile
from pathlib import Path
p=Path('output/172-native-qualified-20261013');state=json.loads((p/'native-state.json').read_text())
# Read the owned WSL archive via a WSL helper, without extracting anything.
