import json,subprocess,sys,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from materialize import STATE,ROOT,PHASE,ARGV,ENV,BASE_ID,capture,checkpoint
assert sys.dont_write_bytecode and ENV['PYTHONDONTWRITEBYTECODE']=='1'
assert json.loads((ROOT/'ownership.json').read_text())['nonce']==STATE['nonce']
assert capture(['info','--format','{{.ID}}'],'cleanup2-engine-id').strip()=='d619836c-83fd-4b61-bccd-28f15d06069f'
assert (PHASE/'cleanup-image-c782833de167.exit').read_text().strip()=='0'
assert (PHASE/'cleanup-absent-c782833de167.exit').read_text().strip()=='1'
assert BASE_ID not in set(json.loads((PHASE/'images-baseline.json').read_text()))
base=json.loads(capture(['image','inspect',BASE_ID],'cleanup2-base-inspect'))[0]
original=json.loads((PHASE/'base-actual.json').read_text())
assert base['Id']==BASE_ID and base['RepoTags']==original['RepoTags']==['python@'+BASE_ID]
assert base['RepoDigests']==original['RepoDigests']==['python@'+BASE_ID]
assert not capture(['ps','-a','--no-trunc','--filter','ancestor='+BASE_ID,'--format','{{.ID}}'],'cleanup2-base-references').strip()
capture(['image','rm',BASE_ID],'cleanup2-base-remove')
r=subprocess.run(ARGV+['image','inspect',BASE_ID],env=ENV,stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
(PHASE/'cleanup2-base-absent.stdout').write_bytes(r.stdout)
(PHASE/'cleanup2-base-absent.stderr').write_bytes(r.stderr)
(PHASE/'cleanup2-base-absent.exit').write_text(str(r.returncode)+'\n')
assert r.returncode==1 and not r.stdout.strip(b' \n\t[]')
current=capture(['ps','-a','--no-trunc','--format','{{.ID}}|{{.State}}'],'cleanup2-containers-after')
assert current==(PHASE/'cleanup-containers-before.stdout').read_text()
report=dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),engine_id='d619836c-83fd-4b61-bccd-28f15d06069f',images=[dict(image_id=STATE['derived_id'],removed=True,baseline_absent=True,nonce_verified=True,no_force=True),dict(image_id=BASE_ID,removed=True,baseline_absent=True,immutable_reference_verified=True,no_force=True)],known_owned_containers_absent=True,baseline_container_states_preserved=True,cache_policy='retain new measured record IDs; no precise safe per-build deletion available; no prune',diagnostic='first cleanup stopped after derived removal because Docker29 exposes the pinned digest reference in RepoTags; second attempt verifies exact baseline pull reference before removing base; original failure retained',borrowed_runtime_policy='read-only; Python -B and PYTHONDONTWRITEBYTECODE=1; no packages modified')
(PHASE/'cleanup-final.json').write_text(json.dumps(report,indent=2)+'\n')
disk=checkpoint('cleanup-final2')
print(json.dumps(dict(images_removed=2,owned_containers_remaining=0,free_c_bytes=disk['free_c_bytes'],introduced_total_conservative_bytes=disk['introduced_total_conservative_bytes'],retained_cache_upper_bound_bytes=disk['new_cache_bytes_upper_bound'])))
