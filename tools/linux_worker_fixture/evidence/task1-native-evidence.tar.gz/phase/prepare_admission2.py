from pathlib import Path
p=Path('output/172-native-qualified-20261013/admit_image.py');s=p.read_text()
s=s.replace('admission-create','admission2-create').replace('admission-container-id','admission2-container-id').replace('admission-container-inspect','admission2-container-inspect').replace('admission-export','admission2-export').replace('admission-remove','admission2-remove').replace('image-rootfs.tar','image-rootfs2.tar')
p2=p.with_name('admit_image2.py');p2.write_text(s,newline='\n')
