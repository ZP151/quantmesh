from pathlib import Path
import hashlib,json,shutil,uuid
phase=Path('output/172-native-qualified-20261013')
nonce=uuid.uuid4().hex
(phase/'ownership.json').write_text(json.dumps(dict(nonce=nonce,source='c545c02093b5f7e3d8dedb5ccc79b128c9dc014f',native_root='/var/tmp/quantmesh-linux-native-'+nonce,engine='unix:///var/run/docker.sock',base_ref='docker.io/library/python@sha256:9ce5a4e59b833c002e1c4196c60ec0b38977e3235d626298ba7ffe2e64f5a30c'),indent=2)+'\n')
shutil.copyfile('src/quantmesh/research/linux_bootstrap.py',phase/'context/linux_bootstrap.py')
paths=['src/quantmesh/research/linux_owned.py','src/quantmesh/research/linux_bootstrap.py','tools/qualify_linux_worker.py','tests/test_linux_owned.py']
records=[dict(path=p,bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in paths]
(phase/'source-seal-phase1.json').write_text(json.dumps(records,indent=2)+'\n')
records=[dict(path=p.relative_to(phase/'context').as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((phase/'context').rglob('*')) if p.is_file()]
(phase/'context-seal-phase1.json').write_text(json.dumps(records,indent=2)+'\n')
print(nonce)
