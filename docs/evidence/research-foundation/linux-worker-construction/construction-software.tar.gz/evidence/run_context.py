import datetime, json, os, shutil, subprocess, sys
from pathlib import Path
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
REPO = Path('/mnt/c/Users/15492/.codex-clean/worktrees/a718/QuantMesh')
PHASE = REPO/'output/172-task2-construction-20261013'
ROOT = Path('/var/tmp/quantmesh-linux-native-90afdbee6add43169483520e384539ae')
assert json.loads((ROOT/'ownership.json').read_text())['nonce'] == '90afdbee6add43169483520e384539ae'
COUNTED = {
 ROOT/'task2-tests': 7867101,
 REPO/'output/172-task2-software-checkpoint1-20261013': 312215,
 Path('/mnt/c/Users/15492/.codex-clean/worktrees/0038-research-integration/QuantMesh/docs/evidence/research-foundation/linux-task2-software'): 326613,
 Path('/mnt/c/Users/15492/.codex-clean/worktrees/0038-research-integration/QuantMesh/docs/evidence/research-foundation/post-auth-source-intake'): 24350,
}
OLD = ['src/quantmesh/research/worker_build.py','src/quantmesh/research/job_runner.py',
       'tests/test_worker_build.py','tests/test_research_job_runner.py',
       'docs/superpowers/plans/2026-10-13-linux-numerical-worker.md','docs/runbooks/linux-research-worker.md']
NEW = ['src/quantmesh/research/worker_execution.py','tests/test_worker_execution.py']
def size(p):
 return sum(f.stat().st_size for f in p.rglob('*') if f.is_file() and not f.is_symlink()) if p.exists() else 0
def observe():
 counts = {str(p):size(p) for p in COUNTED}
 source = sum((REPO/n).stat().st_size for n in OLD+NEW if (REPO/n).exists())
 # Root's conservative original total is never reset. Three source copies are
 # reserved (a718, overlay, future root integration), and decreases never credit.
 total = 8876772 + sum(max(0, counts[str(p)]-base) for p,base in COUNTED.items()) + 3*max(0,source-98831) + size(PHASE)
 value = dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),logical_measured=counts,
   explicit_source_bytes=source,new_phase_bytes=size(PHASE),introduced_logical_upper_bound=total,
   free_c_bytes=shutil.disk_usage('/mnt/c').free,original_baseline_bytes=8876772,
   prior_whole_C_5GB_attribution='PENDING/no waiver/no reset')
 assert total <= 10000000 and value['free_c_bytes'] >= 50000000000, 'software_resource_stop'
 return value
NAME = sys.argv[1]
assert NAME in {'context-red1','context-green1','context-red2','context-green2','context-final1','context-final2'}
before = observe()
for name in [OLD[1],*NEW]:
 if (REPO/name).exists():
  target=ROOT/'source'/name; target.write_bytes((REPO/name).read_bytes())
basetemp=ROOT/'task2-tests'/NAME
assert not basetemp.exists()
selection=['tests/test_worker_execution.py']
if NAME == 'context-red2':
 selection += ['-k', 'changed_admission_after_child_exit']
if NAME == 'context-green2':
 selection += ['-k', 'changed_admission_after_child_exit or heartbeat_denial']
if NAME in {'context-final1', 'context-final2'}:
 selection += ['-k', 'linux_child_refuses_host_fingerprint_without_manifest']
args=[sys.executable,'-B','-m','pytest',*selection,'-q','--tb=short','-p','no:cacheprovider','--basetemp',str(basetemp)]
env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'source/src')}
with (PHASE/(NAME+'.log')).open('wb') as stream:
 r=subprocess.run(args,cwd=ROOT/'source',env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
(PHASE/(NAME+'.exit')).write_text(str(r.returncode)+'\n')
after=observe()
(PHASE/(NAME+'-observation.json')).write_text(json.dumps(dict(before=before,after=after,argv=args,
 source_semantics='explicit targeted overlay on existing owned c545 clone; not whole fd01 clean build',
 mocks='Docker CLI/admission provider only; actual LinuxOwnedProcess and SQLite fences; no native certificate'),indent=2)+'\n')
print(json.dumps(dict(exit=r.returncode,before=before,after=after)))
