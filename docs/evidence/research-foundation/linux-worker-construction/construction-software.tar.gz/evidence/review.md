# Bounded combined Spec/Standards review

Reviewer /root/construction_review, read-only, no tests/probes/materialization.
Round1 P2: fake-Engine Linux owner tests had no explicit platform handling,
while production correctly refuses configured Linux execution on Windows.
Marked all seven Linux-owner functions (nine parameterized cases) skipif host
platform is not Linux. Platform-neutral context/reset/thread test remains.
Only test-platform metadata changed; already-passed groups were not rerun under
root's resource constraint. Ruff/format/diff passed after the decorators.

Round2: host-platform P2 resolved; no remaining P1/P2 in the reviewed slice.
Protocol boundary/deferred actual image/probe admission documented truthfully.
Actual container/numerical/native qualifications are not issued by these tests.
