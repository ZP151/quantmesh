# Construction context checkpoint ledger

Base fd01b5ba9661c50ef9b40eaba9046abf99bcf6a1, own branch codex/0038-linux-worker-jobs.
Original conservative total8,876,772B and10MB cap retained; root's whole-C12.93GB
attribution gate remains pending. No materialization/bulk tests/cleanup allowed.

Ruling: image admission is an independently supplied verify(profile) provider at
the construction boundary, with no built-in saved-bool provider or image certificate.
This checkpoint implements context/actual owned launch and RO/RW/publication loop;
complete byte/probe image admission/producer and trusted baked entry remain separate
required implementations. Wrong provider semantics would invalidate actual runtime
identity; no production admission implementation or native claim is supplied here.

Tests catch context leakage after exception/nesting/independent thread, CLI-success
versus actual nonzero/OOM, bundle/output crossing, cancellation before next pulse,
old post-upload owner publishing and a direct default-Linux call inheriting config.
Real LinuxOwnedProcess and SQLite/math/receipt/publication remain; only Engine and
image-admission provider are mocked because materialization is forbidden.

RED1=7 actual missing-construction assertions ->GREEN1=7pass3.61s. RED2=changed admission post-exit incorrectly succeeded ->GREEN2=2pass7deselect2.53s (new admission recheck + unchanged heartbeat denial boundary). Final1 is deliberately the new Linux-child missing-manifest RED (not a passing final group):1fail9deselect ->Final2=1pass9deselect2.32s. Each run uses -B/env1/nocache and preserves distinct owned basetemp/raw logs; only targeted new boundaries run after GREEN1. All numerical-container/nonzero/OOM/cgroup control-plane evidence is fake Engine with actual production LinuxOwnedProcess API, not native proof. Latest cumulative upperbound9,556,745B/freeC89,294,012,416B before final docs/sealing; original5GB whole-C attribution remains pending. One bounded combined reviewer construction_review now reviewing source; no old Task1/manifest architecture review.

Review round1 P2 test-platform handling -> explicit non-Linux skip metadata on seven functions/nine cases. Round2 clear of P1/P2. Production source unchanged; no repeated passed groups. No third reviewer, actual containers, native qualification or old checkpoint review. Ruling: skip Linux-owner integration cases on other hosts because production requires a Linux owner; platform-neutral construction context remains tested separately. Cost: no Windows-host fake Linux invocation evidence; existing Windows ownership tests remain separately required and were not repeated here. Final source-only Ruff/format/diff pass.
