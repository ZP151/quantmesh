import hashlib, json, runpy, tarfile, sys
from pathlib import Path

# Reuse the same cumulative counter without resetting its starting observation.
saved = sys.argv
sys.argv = ['resource-only', 'context-red1']
runner = Path(__file__).with_name('run_context.py').read_text().split('NAME = sys.argv[1]')[0]
scope = {}
exec(compile(runner, 'cumulative-resource-counter', 'exec'), scope)
sys.argv = saved
repo, phase = scope['REPO'], scope['PHASE']
leaf = repo/'docs/evidence/research-foundation/linux-worker-construction'
source_names = [scope['OLD'][1], *scope['NEW'], scope['OLD'][4], scope['OLD'][5]]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def observed():
 value = scope['observe']()
 # Own tracked evidence and future root copy are additional to ignored raw archive.
 value['own_and_future_root_evidence_bytes'] = 2 * scope['size'](leaf)
 value['introduced_logical_upper_bound'] += value['own_and_future_root_evidence_bytes']
 assert value['introduced_logical_upper_bound'] <= 10000000, 'software_resource_stop'
 return value
before = observed()
freeze = repo/'output/172-task2-software-checkpoint1-20261013/root-task2-interface-freeze.json'
(phase/'root-task2-interface-freeze.json').write_bytes(freeze.read_bytes())
seals = {}
for name in source_names:
 path = repo/name
 entry = dict(bytes=path.stat().st_size, sha256=sha(path))
 if name.endswith('.py'):
  overlay = scope['ROOT']/'source'/name
  entry['tested_overlay_sha256'] = sha(overlay)
  if name.startswith('src/'):
   assert entry['sha256'] == entry['tested_overlay_sha256']
  else:
   entry['post_run_metadata_only'] = 'explicit non-Linux skip decorators/import sys; no test-body or production changes'
   (phase/'tested-test_worker_execution.py').write_bytes(overlay.read_bytes())
 seals[name] = entry
(phase/'source-seal.json').write_text(json.dumps(dict(base='fd01b5ba9661c50ef9b40eaba9046abf99bcf6a1',
 files=seals, source_semantics='targeted explicit overlay on owned c545 clone, not clean whole fd01'),indent=2)+'\n')
archive = phase/'construction-software.tar.gz'
assert not archive.exists()
inputs = [(p, 'evidence/'+p.name) for p in sorted(phase.iterdir()) if p.is_file() and p.name not in {archive.name,'HASHINDEX.json','seal-observation.json'}]
inputs += [(repo/n, 'source/'+n) for n in source_names]
inputs += [(leaf/'README.md', 'README.md')]
with tarfile.open(archive,'w:gz') as tf:
 for p,n in inputs: tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 expected={n:sha(p) for p,n in inputs}
 assert len(tf.getmembers()) == len(inputs)
 for member in tf.getmembers():
  assert member.isfile() and hashlib.sha256(tf.extractfile(member).read()).hexdigest()==expected[member.name]
target=leaf/archive.name
assert not target.exists()
target.write_bytes(archive.read_bytes())
archive_info=dict(name=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(inputs))
(leaf/'SHA256.json').write_text(json.dumps(dict(archive=archive_info,source_files=seals),indent=2)+'\n')
index={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(phase.iterdir()) if p.is_file() and p.name not in {'HASHINDEX.json','seal-observation.json'}}
(phase/'HASHINDEX.json').write_text(json.dumps(dict(archive=archive_info,files=index),indent=2)+'\n')
after=observed()
(phase/'seal-observation.json').write_text(json.dumps(dict(before=before,after=after,archive_verified=True,
 no_new_env_clone_image_container_download_or_native=True, prior_whole_C_5GB_attribution='PENDING'),indent=2)+'\n')
print(json.dumps(dict(archive=archive_info,after=after)))
