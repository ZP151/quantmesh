# Linux numerical Worker Task2 implementation proposal

> For a later authorized implementer: use the available executing-plans/TDD/review/verification lifecycle. This packet does not authorize implementation or execution. Every step below is pending.

**Goal:** Execute existing pinned numerical baselines behind the qualified OCI boundary with truthful image runtime and<=90s two-job recovery.

**Architecture:** Preserve run_next_job's four args through a construction-time runner context. Bake trusted source and the unchanged Linux81-wheel closure into a pinned glibc image, bind actual runtime externally, keep inputsRO/outputRW and retain existing store/report fences.

**Tech stack:** Existing stdlib/Docker/cgroup v2 + frozen NumPy/Pandas/DuckDB/Pydantic dependencies; no added core/service package/lock or daemon.

**Spec:** PROPOSAL.md plus existing docs/superpowers/plans/2026-10-13-linux-worker-containment.md Task2. Root freeze required before execution; root source042fb0b is the inspected baseline, not an implemented Task2 build.

## Constraints and review focus

Keep public four-arg function and nine JobStore methods, schema1 report envelope,
frozen schema/protocol digests, request/engine/dataset pins, CostModel/WalkForward
and publication fences. Global concurrency2, heartbeat15s, lease60s, pulse1s,
PID1 silence5s,900s/2048MiB/CPU1/pids128/swap0/16MiB output/tmpfs defaults.
No real provider/network/keys/orders/service/API/SDK deployment integration.
No new local resources while final storage5GB gate remains PENDING.

Highest-risk cases: no .git/host fingerprint substitution; CLI exit0 with live/
nonzero/OOM container; stale lease/owner cancellation during a blocked store/CLI
call; overlapping mounts or symlink receipts; source/RECORD/Python/image/probe
tamper that would still look superficially canonical. Pin tests to these cases.

## Slice A: Actual image runtime and finite source/dependency preparation

Files: new worker_build.py, tests/test_worker_build.py, deploy/research_worker/
prepare.py/image-admission.py/worker_entry.py/Dockerfile; job_runner.py runtime
fingerprint branch only. Do not change core math/contracts/locks/bootstrap.

Interfaces: measure_worker_runtime(manifest_path)->five-field dict;
validate_worker_admission(profile, record, expected_binding)->frozen admission.
No git required in container; host default fingerprint remains unchanged.

- [ ] RED: no .git with absent manifest refuses; source commit-map/file mismatch,
  extra executable shadow, wrong exact81 version/hash/RECORD/notice/ELF/Python
  bytes, wrong manifest/image/config/entry/controller/probe binding refuse.
  Test host5-field tuple cannot be accepted for a different actual container tuple.
- [ ] Targeted RED only; retain actual failing assertions and exits.
- [ ] Implement byte-inventory/source/metadata collection using existing digest
  semantics plus stricter full byte admission; no final image ID inside baked
  manifest and no self-hash loop. Verify source Git blobs outside image.
- [ ] GREEN tests and freeze producer context bounds/notices/permissions.
- [ ] Only after separate storage/resource/image approval: verify existing wheel
  bytes individually or fetch exact public artifacts into a new owned root;
  never modify borrowed cache/env. Bind actual context SHA before offline build.
- [ ] Measure built image filesystem/config/all ELF dependency edges and symbol
  versions, full OS/GNU/pip/81-wheel notices and exact distribution set. Explicit
  unresolved-license/ELF mismatch returns to root; no opportunistic deletion.
- [ ] Trusted bounded numerical-image probe under actual OCI verifies container
  Python/source/dependency tuple/cgroups and bytes; bind external image admission.
  Existing stdlib-image certificate alone cannot qualify the new image identity.
- [ ] Archive precise disk/base/wheel/layer/cache/context/image measurements;
  stop on5GB/new-total or50GB C-free gate. Small proposal counts are not forecasts
  of actual build footprint. No prune/shared cleanup.
- [ ] Bounded source/evidence review, targeted tests, commit/checkpoint only after
  explicit implementation approval; do not mark native image pass from mocks.

## Slice B: Four-argument runner integration and numerical recovery loop

Files: job_runner.py, new worker_execution.py, tests/test_research_job_runner.py,
new opt-in tools/qualify_linux_worker_jobs.py. No shared store/DTO/math changes.

Interfaces: WorkerRunner(execution=LinuxWorkerExecution|None).run_next_job(fourargs)
wraps original function via private ContextVar; OwnedAttempt poll/pulse/close/
evidence unifies actual Windows Popen and Linux container status.

- [ ] RED: direct function on Linux/no profile/fractional CPU still refuses;
  contexts isolated across two threads; profile does not come from DTO/env/SDK.
  Fake CLI0 with actual container nonzero/OOM/live is rejected. Existing Windows
  suspended-go/EOF/cleanup tests remain and receive -B/env1 child launch controls.
- [ ] RED: readonly bundle job/runtime/dataset and separate absent output are
  chosen correctly; output parent overlap/junction/symlink/escaping or unbounded
  receipt rejects; original dataset/shards unchanged.
- [ ] Implement `_child_command` Windows gate/-B, fixed Linux entry bypassing
  stdin token; `_child_main` input/output path wrapper; common actual poll loop,
  live-fence1s pulse and15s store heartbeat; finally exact CID+nonce close.
- [ ] RED/GREEN parent compares receipt owner/attempt/runtime and actual cgroup/
  image status independently before unchanged canonical schema/publish/finish.
  Timeout/OOM/output cap/nonzero/bad receipt/stale lease never upgrades to success.
- [ ] Run same-image direct-engine equivalence for all3 registered baselines,
  unchanged positive6bps total fee/spread/slippage cost semantics and chronology.
  Cross-environment projection/tolerance tests compare all result fields while
  truthful runtime digests differ. Repeated same-request/image canonical bytes
  and report-envelope SHA must be exactly equal with separate attempt receipts.
- [ ] Native tests below, after explicit later authorization, archive actual CID/
  nonce/status/cgroups/timestamps/receipt/export/sibling/store evidence. No synthetic
  clock advancement in the actual<=90s witness.
- [ ] At the demonstrable slice boundary: relevant targeted checks plus bounded
  review; root owns shared iteration/locks/integration/final exact CI and PR.

## Actual native witness matrix — all PENDING, nothing executed this round

| Witness | Real observation / acceptance |
| --- | --- |
| New numerical image identity | Same fixed controller hash + new actual image/config/source/81-wheel/Python/ELF/notices/probe binding. Reuse existing image-bound foundation witness tool only after new image admission/authorization; never rerun old Task1 digest or architecture reviews just for bookkeeping. |
| Registered baseline and costs | Actual immutable-input numerical fixture in OCI; compare all3 strategies/direct same-image engine, chronology/OOS windows, positive fees/spread/slippage/turnover; finite/null metrics retain existing rules. |
| Repeat identity | Two distinct jobs with identical request/engine/image, independent receipts/CIDs, exact canonical_result/envelope SHA equality; reopen durable store/report. |
| Owner hard crash while numerical child live | Separate host owner os._exit(23), no finally rescue; actual child namespace stops after last pulse near5s while second queued job's actual worker remains running/heartbeating. Exact CID+nonce absence recorded only after exit witness. |
| Two-job lease reclaim<=90s | Default real60s lease/15s heartbeat, global active load2; measure monotonic from confirmed crashing-owner process exit until reclaimed attempt2 has authoritative store succeeded and report reopened. Include queue wait/remaining lease/launch/calculation/publication. Sibling stays running throughout and is deliberately cancelled/closed afterwards. Record last heartbeat/lease expiry/start/end rather than artificially moving clock. |
| Crash after upload, before finish | Actual os._exit(23) test-only trusted host hook after publish_result installs bytes; no old authoritative success. After real lease expiry, same-image retry must yield exactly one store ref and one content-addressed report path; immutable orphan bytes never themselves authorize success. |
| Cancel/reclaimed lease/store heartbeat denied | Real state changes while Worker active close only that CID+nonce; no finish by old owner/attempt, sibling unaffected. Slow/blocked owner cannot use background pulses to mask lost authority. |
| Source/runtime/report tamper | Construct a separate owned invalid bundle/receipt/immutable admission as test inputs; source-map/RECORD/Python/image/manifest/probe mismatch fails before baseline or before publication. Do not edit borrowed/admitted image or mutate base library to manufacture a result. |
| Resource failure and I/O | Actual container OOM137/cpu quota/timeout124/output125 remain non-success; readonly original/snapshot pins; childstdinDEVNULL, -B/env1, zero newly written pyc, absence of routes/socket/HOME/credentials/caps. |
| Sibling and exact cleanup | Independent full CID/nonce exists/runs until controlled cleanup; witness whole attempt closure and no unrelated container/image/cache changes; no name-prefix or global prune. |

Recovery witness control uses only trusted qualification hooks, never job-body
commands or production fault flags. Sibling hold is a test-only allowlisted gate
around the trusted numerical launcher; its presence is not a user code route.
Native queue/stores are owned local fixtures; actual private PostgreSQL/server/
provider/job user loop is a later acceptance gate, not inferred from this witness.

Completion is source+tests+docs+measured native+resource evidence agreement, not
this checklist's existence. Storage/notice/actual-byte/implementation authorization
gates remain explicit. No execution method or additional writer has been selected.
