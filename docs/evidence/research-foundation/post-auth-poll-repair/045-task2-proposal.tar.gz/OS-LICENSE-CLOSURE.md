# Full upstream OS/base license metadata closure

PROPOSAL ONLY. Entire pinned base rootfs is proposed for build and final retention; actual files/notices/ELF/package status are not materialized or admitted. SPDX package rows include source/binary/document entries, not153 claimed installed binary packages. Raw package OR expressions are scanner metadata, not per-file license choice or compliance acceptance.

| SPDX package | Exact version | Declared license (raw scanner value) | Final policy |
| --- | --- | --- | --- |
| sbom | (document) | NOASSERTION | document metadata only |
| acl | 2.3.1-3 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-or-later OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| adduser | 3.134 | GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| apt | 2.6.1 | BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| attr | 1:2.5.1-4 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-or-later OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| audit | 1:3.0.9-1 | GPL-1.0-only OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| base-files | 12.4+deb12u15 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| base-passwd | 3.6.1 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| bash | 5.2.15-2+b13 | BSD-4-Clause-UC OR GFDL-1.3-only OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR Latex2e | retain entire actual base; measure notices/bytes later |
| bsdutils | 1:2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| bzip2 | 1.0.8-5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| ca-certificates | 20250419~deb12u1 | GPL-2.0-only OR GPL-2.0-or-later OR MPL-2.0 | retain entire actual base; measure notices/bytes later |
| cdebconf | 0.270 | BSD-2-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| coreutils | 9.1-1 | BSD-4-Clause-UC OR FSFULLR OR GFDL-1.3-only OR GPL-3.0-only OR GPL-3.0-or-later OR ISC | retain entire actual base; measure notices/bytes later |
| dash | 0.5.12-2 | BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| db5.3 | 5.3.28+dfsg2-1 | BSD-3-Clause OR GPL-3.0-only OR MS-PL OR Sleepycat OR X11 OR Zlib | retain entire actual base; measure notices/bytes later |
| debconf | 1.5.82 | BSD-2-Clause | retain entire actual base; measure notices/bytes later |
| debian-archive-keyring | 2023.3+deb12u2 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| debianutils | 5.7-0.5~deb12u1 | GPL-2.0-only OR GPL-2.0-or-later OR SMAIL-GPL | retain entire actual base; measure notices/bytes later |
| diffutils | 1:3.8-4 | FSFAP OR FSFULLR OR GFDL-1.3-only OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR X11 | retain entire actual base; measure notices/bytes later |
| dpkg | 1.21.23 | BSD-2-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| e2fsprogs | 1.47.0-2+b2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| e2fsprogs | 1.47.0-2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| findutils | 4.9.0-4 | BSD-3-Clause OR FSFAP OR FSFULLR OR GFDL-1.3-only OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR ISC OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR X11 | retain entire actual base; measure notices/bytes later |
| gcc-12-base | 12.2.0-14+deb12u1 | GFDL-1.2-only OR GPL-2.0-only OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| gcc-12 | 12.2.0-14+deb12u1 | GFDL-1.2-only OR GPL-2.0-only OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| gdbm | 1.23-3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| glibc | 2.36-9+deb12u14 | GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| gmp | 2:6.2.1+dfsg1-1.1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| gnupg2 | 2.2.40-1.1+deb12u2 | BSD-3-Clause OR CC0-1.0 OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| gnutls28 | 3.7.9-2+deb12u7 | Apache-2.0 OR BSD-3-Clause OR GFDL-1.3-only OR GPL-3.0-only OR LGPL-3.0-only | retain entire actual base; measure notices/bytes later |
| gpgv | 2.2.40-1.1+deb12u2 | BSD-3-Clause OR CC0-1.0 OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| grep | 3.8-5 | GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| gzip | 1.12-1 | GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| hostname | 3.23+nmu1 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| init-system-helpers | 1.65.2+deb12u1 | BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| keyutils | 1.6.3-2 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| krb5 | 1.20.1-2+deb12u5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libacl1 | 2.3.1-3 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-or-later OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libapt-pkg6.0 | 2.6.1 | BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libattr1 | 1:2.5.1-4 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-or-later OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libaudit-common | 1:3.0.9-1 | GPL-1.0-only OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libaudit1 | 1:3.0.9-1 | GPL-1.0-only OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libblkid1 | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libbz2-1.0 | 1.0.8-5+b1 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libc-bin | 2.36-9+deb12u14 | GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libc6 | 2.36-9+deb12u14 | GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libcap-ng0 | 0.8.3-1+b3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libcap-ng | 0.8.3-1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libcap2 | 1:2.66-4+deb12u3+b1 | BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libcom-err2 | 1.47.0-2+b2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| libcrypt1 | 1:4.4.33-2 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| libdb5.3 | 5.3.28+dfsg2-1 | BSD-3-Clause OR GPL-3.0-only OR MS-PL OR Sleepycat OR X11 OR Zlib | retain entire actual base; measure notices/bytes later |
| libdebconfclient0 | 0.270 | BSD-2-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libext2fs2 | 1.47.0-2+b2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| libffi8 | 3.4.4-1 | GPL-2.0-or-later OR GPL-3.0-or-later OR MPL-1.1 OR X11 | retain entire actual base; measure notices/bytes later |
| libffi | 3.4.4-1 | GPL-2.0-or-later OR GPL-3.0-or-later OR MPL-1.1 OR X11 | retain entire actual base; measure notices/bytes later |
| libgcc-s1 | 12.2.0-14+deb12u1 | GFDL-1.2-only OR GPL-2.0-only OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| libgcrypt20 | 1.10.1-3+deb12u1 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libgdbm6 | 1.23-3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libgmp10 | 2:6.2.1+dfsg1-1.1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libgnutls30 | 3.7.9-2+deb12u7 | Apache-2.0 OR BSD-3-Clause OR GFDL-1.3-only OR GPL-3.0-only OR LGPL-3.0-only | retain entire actual base; measure notices/bytes later |
| libgpg-error0 | 1.46-1 | BSD-3-Clause OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libgpg-error | 1.46-1 | BSD-3-Clause OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libgssapi-krb5-2 | 1.20.1-2+deb12u5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libhogweed6 | 3.8.1-2 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libidn2-0 | 2.3.3-1+b1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libidn2 | 2.3.3-1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libk5crypto3 | 1.20.1-2+deb12u5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libkeyutils1 | 1.6.3-2 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libkrb5-3 | 1.20.1-2+deb12u5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libkrb5support0 | 1.20.1-2+deb12u5 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| liblz4-1 | 1.9.4-1 | BSD-2-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| liblzma5 | 5.4.1-1+deb12u2 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR LGPL-2.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libmd0 | 1.0.4-2 | BSD-2-Clause OR BSD-3-Clause OR Beerware OR ISC | retain entire actual base; measure notices/bytes later |
| libmd | 1.0.4-2 | BSD-2-Clause OR BSD-3-Clause OR Beerware OR ISC | retain entire actual base; measure notices/bytes later |
| libmount1 | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libncursesw6 | 6.4-4 | BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| libnettle8 | 3.8.1-2 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libnsl2 | 1.3.0-2 | BSD-3-Clause OR GPL-2.0-only OR GPL-3.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libnsl | 1.3.0-2 | BSD-3-Clause OR GPL-2.0-only OR GPL-3.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libp11-kit0 | 0.24.1-2 | Apache-2.0 OR BSD-3-Clause OR ISC OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libpam-modules-bin | 1.5.2-6+deb12u2 | BSD-3-Clause OR Beerware OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libpam-modules | 1.5.2-6+deb12u2 | BSD-3-Clause OR Beerware OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libpam-runtime | 1.5.2-6+deb12u2 | BSD-3-Clause OR Beerware OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libpam0g | 1.5.2-6+deb12u2 | BSD-3-Clause OR Beerware OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libpcre2-8-0 | 10.42-1+deb12u2 | BSD-2-Clause OR BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| libreadline8 | 8.2-1.3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| libseccomp2 | 2.5.4-1+deb12u1 | LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libseccomp | 2.5.4-1+deb12u1 | LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libselinux1 | 3.4-1+b6 | GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libselinux | 3.4-1 | GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libsemanage-common | 3.4-1 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| libsemanage2 | 3.4-1+b5 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| libsemanage | 3.4-1 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| libsepol2 | 3.4-2.1 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR Zlib | retain entire actual base; measure notices/bytes later |
| libsepol | 3.4-2.1 | GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR Zlib | retain entire actual base; measure notices/bytes later |
| libsmartcols1 | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libsqlite3-0 | 3.40.1-2+deb12u2 | GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| libss2 | 1.47.0-2+b2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| libssl3 | 3.0.22-1~deb12u1 | Apache-2.0 OR GPL-1.0-only OR GPL-1.0-or-later | retain entire actual base; measure notices/bytes later |
| libstdc++6 | 12.2.0-14+deb12u1 | GFDL-1.2-only OR GPL-2.0-only OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| libsystemd0 | 252.39-1~deb12u2 | CC0-1.0 OR GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libtasn1-6 | 4.19.0-2+deb12u1 | GFDL-1.3-only OR GPL-3.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libtinfo6 | 6.4-4 | BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| libtirpc-common | 1.3.3+ds-1 | BSD-3-Clause OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libtirpc3 | 1.3.3+ds-1 | BSD-3-Clause OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libtirpc | 1.3.3+ds-1 | BSD-3-Clause OR GPL-2.0-only OR LGPL-2.1-only | retain entire actual base; measure notices/bytes later |
| libudev1 | 252.39-1~deb12u2 | CC0-1.0 OR GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| libunistring2 | 1.0-2 | GFDL-1.2-only OR GFDL-1.2-or-later OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libunistring | 1.0-2 | GFDL-1.2-only OR GFDL-1.2-or-later OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libuuid1 | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| libxcrypt | 1:4.4.33-2 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| libxxhash0 | 0.8.1-1 | BSD-2-Clause OR GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| libzstd1 | 1.5.4+dfsg2-5 | BSD-3-Clause OR GPL-2.0-only OR Zlib | retain entire actual base; measure notices/bytes later |
| libzstd | 1.5.4+dfsg2-5 | BSD-3-Clause OR GPL-2.0-only OR Zlib | retain entire actual base; measure notices/bytes later |
| login | 1:4.13+dfsg1-1+deb12u2 | BSD-3-Clause OR GPL-1.0-only OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| logsave | 1.47.0-2+b2 | Apache-2.0 OR BSD-3-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR ISC OR Kazlib OR LGPL-2.0-only OR Latex2e | retain entire actual base; measure notices/bytes later |
| lz4 | 1.9.4-1 | BSD-2-Clause OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| mawk | 1.3.4.20200120-3.1 | CC-BY-3.0 OR GPL-2.0-only OR X11 | retain entire actual base; measure notices/bytes later |
| mount | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| ncurses-base | 6.4-4 | BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| ncurses-bin | 6.4-4 | BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| ncurses | 6.4-4 | BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| netbase | 6.4 | GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| nettle | 3.8.1-2 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| openssl | 3.0.22-1~deb12u1 | Apache-2.0 OR GPL-1.0-only OR GPL-1.0-or-later | retain entire actual base; measure notices/bytes later |
| p11-kit | 0.24.1-2 | Apache-2.0 OR BSD-3-Clause OR ISC OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| pam | 1.5.2-6+deb12u2 | BSD-3-Clause OR Beerware OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| passwd | 1:4.13+dfsg1-1+deb12u2 | BSD-3-Clause OR GPL-1.0-only OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| pcre2 | 10.42-1+deb12u2 | BSD-2-Clause OR BSD-3-Clause OR X11 | retain entire actual base; measure notices/bytes later |
| perl-base | 5.36.0-7+deb12u4 | Artistic-2.0 OR BSD-3-Clause OR GPL-1.0-only OR GPL-1.0-or-later OR GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR Zlib | retain entire actual base; measure notices/bytes later |
| perl | 5.36.0-7+deb12u4 | Artistic-2.0 OR BSD-3-Clause OR GPL-1.0-only OR GPL-1.0-or-later OR GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR Zlib | retain entire actual base; measure notices/bytes later |
| readline-common | 8.2-1.3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| readline | 8.2-1.3 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| sed | 4.9-1+deb12u1 | BSD-4-Clause-UC OR BSL-1.0 OR GFDL-1.3-only OR GPL-3.0-only OR GPL-3.0-or-later OR ISC OR X11 | retain entire actual base; measure notices/bytes later |
| shadow | 1:4.13+dfsg1-1+deb12u2 | BSD-3-Clause OR GPL-1.0-only OR GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| sqlite3 | 3.40.1-2+deb12u2 | GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| systemd | 252.39-1~deb12u2 | CC0-1.0 OR GPL-2.0-only OR GPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| sysvinit-utils | 3.06-4 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| sysvinit | 3.06-4 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only | retain entire actual base; measure notices/bytes later |
| tar | 1.34+dfsg-1.2+deb12u1 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later | retain entire actual base; measure notices/bytes later |
| tzdata | 2026c-0+deb12u1 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |
| usr-is-merged | 37~deb12u1 | GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| usrmerge | 37~deb12u1 | GPL-2.0-only OR GPL-2.0-or-later | retain entire actual base; measure notices/bytes later |
| util-linux-extra | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| util-linux | 2.38.1-5+deb12u3 | BSD-3-Clause OR BSD-4-Clause OR GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR GPL-3.0-or-later OR LGPL-2.0-only OR LGPL-2.0-or-later OR LGPL-2.1-only OR LGPL-2.1-or-later OR LGPL-3.0-only OR LGPL-3.0-or-later OR MIT | retain entire actual base; measure notices/bytes later |
| xxhash | 0.8.1-1 | BSD-2-Clause OR GPL-2.0-only | retain entire actual base; measure notices/bytes later |
| xz-utils | 5.4.1-1+deb12u2 | GPL-2.0-only OR GPL-2.0-or-later OR GPL-3.0-only OR LGPL-2.0-only OR LGPL-2.1-only OR LGPL-2.1-or-later | retain entire actual base; measure notices/bytes later |
| zlib1g | 1:1.2.13.dfsg-1 | Zlib | retain entire actual base; measure notices/bytes later |
| zlib | 1:1.2.13.dfsg-1 | Zlib | retain entire actual base; measure notices/bytes later |
| pip | 25.0.1 | MIT | retain entire actual base; measure notices/bytes later |
| python | 3.12.15 | NULL � exact notice resolution pending | retain entire actual base; measure notices/bytes later |

There are150 Debian purl entries, pip25.0.1, CPython3.12.15 and the document row. Nine null declared-license rows plus one NOASSERTION document row are explicitly unresolved; CPython upstream full notices are separately hash-bound. Source/binary duplicates do not imply runtime compiler executables exist. Full retained SPDX in attestation-1-0.json.gz binds package identities and3,229 file hashes to the immutable manifest.

Final proposed additions: all81 exact wheel distributions listed in linux-wheels.json, isolated venv/Python copies/config, QuantMesh trusted source/controller/entry, and measured build/inventory manifests. The unchanged LICENSE is Apache-2.0. Retain full base /usr/share/doc/*/copyright and /usr/share/common-licenses; all base pip/vendor notices; CPython historical and embedded notices; every wheel dist-info/bundled-library notice. Actual notice/ELF/source-byte admission remains PENDING. No wheel/source/runtime layer was downloaded for this list.

Upstream authority: https://gcc.gnu.org/onlinedocs/libstdc++/manual/license.html identifies the GPLv3 GCC Runtime Library Exception3.1 for libstdc++ code; actual Debian package copyright/exception mapping must still be verified. Metadata labels for libbz2/sqlite/OpenSSL aggregate packaging/source licenses and are not automatically interpreted as the license of every runtime ELF.
