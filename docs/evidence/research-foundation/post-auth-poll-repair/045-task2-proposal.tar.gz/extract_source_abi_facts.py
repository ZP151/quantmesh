import gzip,hashlib,json,os,re,subprocess,sys
from pathlib import Path
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
repo=Path.cwd();out=repo/'output/172-task2-proposal-20261013'
sha='042fb0b491c13f4535bddbb61290b191d29b1790'
def git_bytes(name):return subprocess.check_output(['git','show',sha+':'+name])
def norm(name):return re.sub(r'[-_.]+','-',name).lower()
lock_path='services/research_agent/requirements.linux-cp312.lock'
raw=git_bytes(lock_path)
assert hashlib.sha256(raw).hexdigest()=='07f4e7ec64805a375e0bdc707d0158fbdb08bd07d02aa569e2d119496b32592a'
pins={norm(m[1]):dict(name=m[1],version=m[2],sha256=m[3]) for line in raw.decode().splitlines() if (m:=re.fullmatch(r'([\w.-]+)==(\S+) --hash=sha256:([0-9a-f]{64})',line))}
assert len(pins)==81
receipt_path='docs/evidence/research-foundation/linux-service-cp312/native-install.json'
receipt=json.loads(git_bytes(receipt_path))
inventory_path='docs/evidence/research-foundation/native-service-bf64883/runtime-wheel-inventory.json'
inventory=json.loads(git_bytes(inventory_path))
service_path='docs/evidence/research-foundation/native-service-bf64883/service-gate.json'
service=json.loads(git_bytes(service_path));licenses={norm(x['name']):x for x in service['licenses']}
assert len(licenses)==81
wheels=[]
for item in receipt['install']:
 meta=item['metadata'];key=norm(meta['name']);pin=pins[key]
 url=item['download_info']['url'];digest=item['download_info']['archive_info']['hashes']['sha256']
 assert digest==pin['sha256'] and meta['version']==pin['version']
 actual=inventory[digest]
 assert norm(actual['name'])==key and actual['version']==pin['version']
 filename=url.rsplit('/',1)[1]
 # Wheel filenames can choose compressed-tag aliases for identical audited bytes.
 old_filename=actual['wheel']
 wheel_platform=filename.removesuffix('.whl').rsplit('-',1)[1]
 floors=[tuple(map(int,m)) for m in re.findall(r'manylinux_([0-9]+)_([0-9]+)_x86_64',wheel_platform)]
 for legacy,floor in [('manylinux1_', (2,5)),('manylinux2010_', (2,12)),('manylinux2014_', (2,17))]:
  if legacy in wheel_platform:floors.append(floor)
 assert not floors or max(floors)<=(2,36)
 assert 'musllinux' not in wheel_platform and ('x86_64' in wheel_platform or wheel_platform=='any')
 wheels.append(dict(name=pin['name'],version=pin['version'],url=url,filename=filename,sha256=digest,license_inventory=licenses[key]['license'],declared_metadata_license=meta.get('license_expression') or meta.get('license'),requires_python=meta.get('requires_python'),requires_dist=meta.get('requires_dist',[]),wheel_platform=wheel_platform,glibc_declared_tag_floors=floors,previous_audited_cache_filename=old_filename,filename_alias_equal_digest=filename!=old_filename,previous_cached_compressed_bytes=actual['bytes'],new_wheel_downloaded=False,new_container_elf_measured=False))
assert len(wheels)==len(pins)==81
(out/'linux-wheels.json').write_text(json.dumps(wheels,indent=2)+'\n')
packages=json.loads((out/'base-packages.json').read_text())
nulls=[dict(name=p['name'],version=p['versionInfo'],license=p['licenseDeclared'],SPDXID=p['SPDXID']) for p in packages if not p.get('licenseDeclared') or p['licenseDeclared']=='NOASSERTION']
raw_sbom=gzip.decompress((out/'attestation-1-0.json.gz').read_bytes());sbom=json.loads(raw_sbom)['predicate']
purl_counts={}
for p in packages:
 for e in p.get('externalRefs') or []:
  if e.get('referenceType')=='purl':
   kind=e['referenceLocator'].split(':',1)[1].split('/',1)[0];purl_counts[kind]=purl_counts.get(kind,0)+1
core_names={'libc6','libstdc++6','libgcc-s1','libffi8','libssl3','libsqlite3-0','libbz2-1.0','liblzma5','libreadline8','libtinfo6','libgdbm6','zlib1g'}
source_paths=['docs/superpowers/plans/2026-10-13-linux-worker-containment.md','src/quantmesh/research/job_runner.py','src/quantmesh/research/linux_owned.py','src/quantmesh/research/linux_bootstrap.py','src/quantmesh/research/job_store.py','src/quantmesh/research/jobs.py','src/quantmesh/research/job_artifacts.py','src/quantmesh/research/baselines.py','src/quantmesh/research/reports.py','src/quantmesh/research/strategy_registry.py','tests/test_research_job_runner.py',lock_path,receipt_path,inventory_path,service_path]
source=[dict(path=p,bytes=len(data:=git_bytes(p)),sha256=hashlib.sha256(data).hexdigest(),git_blob=subprocess.check_output(['git','rev-parse',sha+':'+p],text=True).strip()) for p in source_paths]
facts=dict(source_commit=sha,source_tree=subprocess.check_output(['git','rev-parse',sha+'^{tree}'],text=True).strip(),read_only_local_branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),local_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_files=source,lock_sha256=hashlib.sha256(raw).hexdigest(),wheel_count=81,binary_tagged_wheels=sum(w['wheel_platform']!='any' for w in wheels),maximum_declared_glibc_tag=list(max(t for w in wheels for t in w['glibc_declared_tag_floors'])),previous_cached_compressed_wheel_bytes=sum(w['previous_cached_compressed_bytes'] for w in wheels),previous_linux_python=receipt['environment']['python_full_version'],candidate_python='3.12.15',candidate_glibc_from_sbom=next(p['versionInfo'] for p in packages if p['name']=='libc6'),core_ELF_package_metadata=[p for p in packages if p['name'] in core_names],unresolved_SPDX_license_rows=nulls,SPDX_purl_type_counts=purl_counts,SPDX_package_rows=153,SPDX_sha256_file_rows=sum(any(c['algorithm']=='SHA256' for c in f.get('checksums',[])) for f in sbom.get('files',[])),prior_qualification=dict(source='bf64883',scope='DEPENDENCY/OFFLINE_SERVICE_ONLY',record_files=6669,bytecode_files=0,packages_licensed=81,container_qualification=False),frozen_schema_digest=service['schema_digest'],frozen_protocol_digest=service['protocol_digest'],new_native_tests_executed=False,new_product_code_written=False,storage_gate='PENDING',packet_max_bytes=2000000)
(out/'source-abi-facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({k:facts[k] for k in ['source_commit','wheel_count','binary_tagged_wheels','maximum_declared_glibc_tag','previous_cached_compressed_wheel_bytes','candidate_glibc_from_sbom','SPDX_purl_type_counts','frozen_schema_digest','frozen_protocol_digest']}))
print(json.dumps(dict(unresolved_license_rows=nulls)))
