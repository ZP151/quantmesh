# Issue172 Task2 design proposal — 2026-10-13

Status: **PROPOSAL ONLY — root interface freeze and execution authorization pending**.
This is an architectural design refinement of the already approved Worker Task2,
not a new platform choice. No implementation, image build, wheel/layer download,
container, environment, native test, bulk test, review delegation or cleanup was
performed in this round. All new packet bytes must remain below2,000,000B.

## Intended user loop and scope

One operator action: execute an already queued, pinned, registered fixture baseline
on an explicitly configured Linux Worker, then reopen its authoritative report.
Success: unchanged report mathematics/pins/envelope, truthful container runtime
identity, and actual two-job crash/reclaim recovery within90 seconds with a surviving
sibling and exactly one authoritative publication. Every execution test is pending.

Read source is root commit042fb0b491c13f4535bddbb61290b191d29b1790, whose exact Git
blobs are listed in source-abi-facts.json. a718 remains at published Task1
f818a553c024169b2e3a61dcd6fa8941774cf43b; no checkout/merge/commit/push in this round.
Root's new exact CI38365280962 is independently live; no CI result is inferred.

Non-goals: new strategies, arbitrary/uploaded/generated Python, DTO/schema/store
method changes, numerical changes, source/data/model/vendor credentials in the
child, online model calls, service/API wiring, SDK configuration, core/service
packages or locks, OpenD/helper/tunnel changes, AWS provisioning/deploy or live
trading. Long-term service remains planned AWS Singapore quantmesh-research-8gb.
The unexplained previous whole-C delta/resource acceptance remains PENDING.

## Grounded findings

job_runner.py:49 runtime_fingerprint hashes every quantmesh source .py, installed
METADATA/RECORD/direct_url.json, sys.version, executable bytes, platform/machine,
then executes git rev-parse HEAD at _REPO. The five return fields are
build_digest, dependency_digest, git_commit, python_version,
python_executable_digest. It identifies metadata; today it does not measure every
installed executable byte. The parent calls it at354, child at281, then compares
the receipt to the parent's runtime at395. A container with no .git must not run
this Git path or receive the host's runtime as its claimed actual identity.

_OwnedChild:179 is Windows-only. _child_command:266 has a Windows stdin go gate,
but no -B; _child_main:276 assumes writable job/runtime/input/registry/result all
under one attempt directory. run_next_job:334 polls child.process and reads its
returncode. LinuxOwnedProcess exposes its own poll/pulse/close; its transport's
Popen is a Docker CLI, not the Worker. Its input/output mounts must be distinct
descendants of profile.fixture_root; output must not exist before construction.

The unchanged registry pins strategy-id + baselines.py + reports.py bytes. The
baseline receives job.implementation_digest explicitly, so report creation does
not need reports.current_commit() or Git in the image. canonical_result excludes
only created_at and retains runtime evidence. JobStore.finish alone grants
success under owner/attempt/live-lease fencing; upload alone never grants it.
There is currently no source/service/tool call site of run_next_job outside its
definition: production scheduling/wiring is a later root slice, not hidden here.

## Selected image and ABI proposal

Recommend the exact official Linux amd64 manifest:

`docker.io/library/python@sha256:2ed6491b93cd49272ee6de2b5a38440c3448360322c089fc23e370722d74179d`

Discovery tag3.12.15-slim-bookworm; multi-platform index
34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258;
separate config digest4f228bc1cbcfc794e4878312cfc241d368eff55a21c08d1e2bb263116c4ef524.
Packaging Git2a3b794c223ab067d122719541cdd54a068732a5, directory3.12/slim-bookworm,
Dockerfile byte SHA256c685895e7edfceb6ba2f0fcff42b16062cf19d0bf3064ebc922be0d90ec49bb7.
CPython3.12.15 source XZ SHA256
c2c4321961fab0fb999d66e0cecf521c2ab3994c7992873ea99e306c1094fd5a matches the
[official release](https://www.python.org/downloads/release/python-31215/).
Source tar was not downloaded. Official Docker packaging MIT notice and CPython
LICENSE/Doc/license.rst bytes are retained and hash-bound in registry-intake.json.

Exact descriptors/config/SPDX/SLSA subjects were checked against downloaded public
metadata bytes. Compressed runtime layers total47,558,478B; none downloaded.
SPDX raw SHA256f0ffe2d8268bb08f1b334592390f2a14276a723f8e471acdafeb31fea9bcec71
(2,575,079B) is retained as lossless447,434B gzip; provenance raw SHA256
d135d806d9f92d67d4e5fe199f1c4f945a414a4e369f3bf67001e2d0466e54a5
(23,676B) as8,101B gzip. This proves registry metadata association, not a signed
operator attestation or materialized bytes. SLSA lists reproducible=false and
Debian upstream material a4672c0cb26fbdde88e38fa2dfb6c681942306680e41e4378b28770b6e79ee91.

SPDX declares libc6/glibc2.36-9+deb12u14, libstdc++6/libgcc-s1
12.2.0-14+deb12u1 and the CPython optional runtime libraries. The frozen Linux
cp312 lock SHA25607f4e7ec64805a375e0bdc707d0158fbdb08bd07d02aa569e2d119496b32592a
has81 wheels,19 platform-tagged. Full81 exact name/version/hash inventory matches
the earlier native installer and audited cache receipts; the previous complete
wheel archive total was88,992,477B, not a newly measured runtime footprint.
Highest declared manylinux floor is2.34 (cryptography50 cp311-abi3); numpy2.5.2
declares2.27/2.28 and DuckDB1.5.5 declares2.26/2.28. `linux-wheels.json` names every
wheel URL/hash, ABI tag, prior byte count and license inventory; Windows77 is not
substituted. Alias filenames with identical audited byte hashes are disclosed.

This is tag-level ABI compatibility, following [PEP600](https://peps.python.org/pep-0600/)
and [CPython's ABI policy](https://docs.python.org/3.12/c-api/stable.html). It is not
an ELF/import/numerical certificate for3.12.15. The prior environment was3.12.3.
Task1's Alpine/musl image cannot satisfy this glibc closure. Do not add a musl shim
or rebuild/replace frozen wheels to conceal that mismatch.

Alternatives considered: retain Alpine would need a different musllinux/source
closure and break the frozen dependency scope; repack the borrowed Ubuntu venv
would import unpinned system-library/compiler/path dependencies and risk touching
borrowed resources. The official pinned glibc base plus independent offline
installation of the exact81 wheels gives a finite closure without those changes.

## Full OS/dependency/license boundary

Recommend retaining the **entire official base filesystem** in final FROM scratch,
then adding an isolated /opt/quantmesh/venv and full trusted source. This resets
image config without silently deleting shared libraries, data, notices, shell,
package manager or pip. Their presence is disclosed; the production invocation
still exposes only a fixed baseline launcher under network=none/non-root/no caps.
Base GPG_KEY is public upstream configuration, not a credential, but is absent
from final image Env. Only PATH/LANG/PYTHONDONTWRITEBYTECODE are final Env.
No additional apt package, compiler, wheel, SDK, lock or root service is proposed.

The full153 SPDX package rows (150 Debian purls, pip, CPython, document row) are
listed with raw declared/concluded licenses in base-packages.json and
OS-LICENSE-CLOSURE.md. They include source/binary representations: **153 is not
claimed as the number of installed OS binary packages**. Keeping the entire
base retains all actual base packages; no minimal-runtime license exemption is
claimed. GPL/LGPL/GFDL/readline/coreutils/bash/apt/dpkg and pip/vendor notices are
part of the final disclosure, unlike the previous curated stdlib fixture.

Scanner package-level OR expressions are preserved literally, not treated as
per-file license choices. GNU libstdc++ has a runtime exception in its
[upstream notice](https://gcc.gnu.org/onlinedocs/libstdc++/manual/license.html),
which must be matched to the actual Debian copyright/exception bytes later.
SPDX has nine null license rows (base-files, Debian keyring, libcrypt1/libxcrypt,
three libsemanage representations, tzdata, CPython) plus its NOASSERTION document
row. CPython's upstream notice is already present; the remaining exact Debian
notice resolution is a named admission gate, not silently mapped to permissive.
Retain actual /usr/share/doc/*/copyright, /usr/share/common-licenses, CPython
historical/embedded notices, base pip/vendor notices, all81 wheel dist-info
notices and bundled libraries' notices. The previous81-package licensed metadata
and6,669 RECORD checks prove that previous env only; they do not certify every
bundled notice or byte of the proposed image. No license green claim is made.

Expected system SONAME families (metadata-supported, actual edges pending):
ld-linux-x86-64.so.2, libc.so.6/libm.so.6, libpython3.12.so.1.0,
libstdc++.so.6/libgcc_s.so.1, libssl.so.3/libcrypto.so.3, libffi.so.8,
libsqlite3.so.0, libbz2.so.1.0/liblzma.so.5/libz.so.1,
libreadline.so.8/libtinfo.so.6/libgdbm.so.6. Keep all other base dependencies too.
NumPy wheel-bundled BLAS/Fortran/quadmath libraries and every wheel ELF must have
its actual DT_NEEDED/RPATH/RUNPATH/PT_INTERP/symbol versions measured. If a library
such as libgomp is really required but absent, refuse admission and return the
specific edge to root; do not install/drop/replace components opportunistically.

Dockerfile.proposed is an unexecuted build layout, with producer/admission scripts
explicitly NOT IMPLEMENTED. Future offline build would verify exact local wheel
hashes, create a --without-pip --copies venv at its final path, use the base's pip
to install all81 exact wheels with --no-index/--no-deps/--require-hashes/
--only-binary/--no-compile/--no-cache-dir, and preserve the build install report.
The base pip version25.0.1 supports the [--python option](https://pip.pypa.io/en/stable/topics/python-option/).
No borrowed venv is copied or cleaned. Every build Python/child uses -B and
PYTHONDONTWRITEBYTECODE=1. Final venv contains exactly81 frozen distributions;
base global pip remains a separately inventoried base component, outside that
venv's distribution fingerprint. Proposed retention minimizes ABI guesswork;
future physical/base/wheel/cache/context sizes and5GB/C-free gates remain pending.

## Construction-only execution interface

Recommend a frozen LinuxWorkerExecution constructed from a validated
LinuxExecutionProfile and LinuxWorkerImageAdmission. The admission is an
operator-approved immutable record bound to exact Engine ID, returned Image ID
(config digest separately), controller/entry/source/lock/manifest/inventory SHA,
and a measured numerical-image probe/native witness. It has no ready/qualified
boolean as authority. `admit_linux_worker(profile, expectation)` validates these
bindings and actual fixed-local-engine image/config; any identity/capability
change refuses. Certificate/code names here are draft interfaces, not existing.

`WorkerRunner(*, execution: LinuxWorkerExecution | None = None)` stores that
immutable execution selection at construction. Its
`run_next_job(store, owner, inputs_root, artifacts_root)` uses a private ContextVar
only around the existing public four-argument run_next_job call and resets it
in finally. No module-global mutable profile; each thread invokes its own
constructed runner. Direct run_next_job defaults to None: unchanged Windows Job
Object behavior, explicit Linux/fractional-CPU refusal. Context is never taken
from job body, environment, SDK provider registry or a request DTO. It cannot
authorize another command or choose an image. Task2's configured owner is native
Linux/POSIX; a profile on an unsupported owner/platform refuses rather than
claiming the Windows host has qualified native owner-loss semantics.

The ContextVar is narrow compatibility plumbing. An optional fifth public
argument would alter the frozen interface; a global configuration setter would
leak across owners/tests. This proposal selects the construction wrapper instead.
No service/SDK caller exists yet; first consumers are the owned qualification
tool/tests. Actual service scheduling/injection belongs to root's later slice.

One internal OwnedAttempt protocol: poll()->int|None, pulse()->None,
close()->None and evidence:Mapping. _OwnedChild gains adapters around its actual
Popen/Job Object (pulse is a no-op), preserving suspended-before-assignment and
stdin go handshake. The Linux wrapper delegates to LinuxOwnedProcess, whose
poll inspects actual container state/OOM, never transport.process.returncode.
run_next_job retains its0.1s supervision cadence but stores the returned actual
exit code and no longer exposes .process in the common loop.
Linux admission/control/poll errors need an explicit sanitized exception mapping
in job_runner.py (UnsupportedLimits before launch, worker_failed after launch),
because LinuxContainmentError is currently a RuntimeError outside its catch list.
Keep failed exact-CID cleanup retryable; never rescue with a prefix/global search
or let raw Docker payloads enter report/error output.

## Attempt layout and supervision

Linux attempt path remains under artifacts_root/job-id/receipts/attempt-id. Its
two sibling directories are `bundle` (created/private, then mountedRO at/inputs)
and `output` (absent until LinuxOwnedProcess creates it, mountedRW at/output).
profile.fixture_root must be an operator-owned ancestor of artifacts_root;
UID/GID must be numeric/non-root and permit that owner's input/output access.
No ancestor/descendant overlap, symlink/junction, missing implicit bind or host
HOME/source/credential/DB/daemon mount. Source/code/manifests are baked read-only
in the image, never overlaid by host editable source. Original dataset root and
JobStore/credentials are never mounted. bundle contains job.json,
runtime.json (expected measured container runtime) and inputs/<dataset>/exact
manifest-covered shards. _snapshot/_verify remain authoritative before/after
copy; the256MiB snapshot limit and pin_changed_during_snapshot rejection remain.

The fixed Linux child command is
`/opt/quantmesh/venv/bin/python3 -B -I /opt/quantmesh/worker_entry.py`
with fixed /inputs and/output arguments. worker_entry is stdlib-first, verifies
the baked manifest/source/dependency bytes, sets OPENBLAS_NUM_THREADS=1 and
OMP_NUM_THREADS=1 before numerical imports, and inserts only the baked source
path. It does not read stdin (DEVNULL from existing PID1); the Windows launcher
retains its separate go gate. No arbitrary argv/user code is admitted. All
launches and generated Python children preserve -B/env1. Existing PID1/bootstrap
and LinuxOwnedProcess can remain byte-identical; the numerical entry sets its
own bounded process environment after PID1's clean-env launch.

Owner emits a pulse at least every1s in its live supervision loop, after checking
the store state/owner/attempt/lease/cancel fence. Store heartbeat remains15s and
lease60s, global concurrency2; default900s/2048MiB/exact1CPU/pids128/swap0,
16MiB output admission bound and16MiB tmpfs remain. No automatic pulse thread
that can outlive the active owner or mask stale lease authority. Actual Engine
calls currently have5s maximum; stalled Engine/store calls can therefore trigger
the independent5s watchdog and fail closed. Pulse timing/latency is measured in
Task2 rather than presumed to stay under1s during a hang. Store stalls are not
permission to keep pulsing a stale attempt. A pulse write has its existing1s
bound. Cancellation/failed heartbeat/expired or reclaimed lease returns the
store's current record and closes only the exact CID+nonce in finally. PID1
watchdog independently handles os._exit/EOF/hung attach; unrelated sibling lives.

## Worker build manifest and actual runtime fingerprints

Proposed read-only `/opt/quantmesh/worker-build.json` binds: source commit/tree,
complete source path/byte SHA/Git blob inventory (including entry/controller),
base manifest/config/layers, full81 exact wheel archive hashes, unchanged Linux
lock digest, full installed executable/metadata/notice inventory, resolved image
symlinks and actual Python executable/libpython/stdlib/ELF-byte hashes. The
post-build actual probe runtime is in the external admission record, not baked
into a manifest that would change the image being probed. No .git is shipped and
no HEAD is fabricated. Builder verifies
a clean exact source commit/tree with Git blobs before preparing its finite
context; runtime never invokes Git. Source commit is only returned after actual
source/inventory validation against an independently admitted image record.

Avoid a circular ID: the baked manifest does NOT contain its own final Image ID
or the SHA of its own bytes. External ImageAdmission binds the actual returned
Image ID to worker-build.json SHA + inventory SHA + source commit + lock/controller
SHA. A probe result written after image construction is external as well, and
bound to that actual image. A saved JSON bool/tag/user label cannot confer trust.
Image labels are cross-checks, not source/byte proof. The final image is not
assumed byte-reproducible merely because its input metadata is pinned.

`measure_worker_runtime(manifest_path)->dict` (new stdlib helper) validates full
admitted source/dependency/Python/library bytes first, then preserves the current
five-field runtime shape and existing build/dependency digest algorithm. It
reads container sys.version/sys.executable/executable bytes/importlib metadata,
sys.platform and machine, never host values. Full byte admission is additional
to, not a deceptive reinterpretation of, the old metadata fingerprint. Exact
installed81 name/version/RECORD/METADATA/direct_url manifests are checked;
unadmitted executable shadows/extra .py/.so/.pth/.pyc refuse. Known baked base
symlinks are enumerated/contained; arbitrary input links remain forbidden.

Host `validate_worker_admission(profile, record, expected_binding)` independently
checks immutable image identity/config and source+dependency file inventories
against an approved inspection export/probe; no baseline authority is granted
by reading child output alone. A qualification-time trusted probe measures the
actual container's full runtime tuple after offline inventory admission. Parent
uses that image-bound expected tuple in bundle/runtime.json and compares the
receipt's actual tuple to it. Its own host runtime may be recorded separately
for diagnostics but never substituted. worker_entry validates actual bytes and
tuple before _child_main can calculate the baseline. The child verifies kernel
cgroup files again and reports limits with memory_semantics=cgroup_v2_tree,
not the currently misleading Linux process_address_space value. Host checks
actual LinuxOwnedProcess evidence against the job budget/receipt before publication.

Keep receipt keys report/runtime/attempt/owner/fixture_only/limits, existing
runtime five fields, schema1 publication envelope, report ID/field set, all
dataset/request/engine pins and numerical validation unchanged. Per-attempt
execution-evidence.json holds image/config/CID/nonce/kernel/cgroup/probe/manifest
bindings outside canonical report identity; no new public DTO or store schema.
Parent validates receipt owner and attempt, bounded contained regular files,
canonical StrategyReport result, image runtime and actual terminal container
success before the unchanged pre-publication heartbeat/publish_result/finish.
store.finish false remains no success even if immutable bytes were uploaded.

## Numerical equivalence and identity

1. On the same proposed image, run each registered baseline against the identical
pinned fixture and compare to a direct call of the unchanged numerical engine
in that image. Require exact metrics/windows first (matching existing test);
all setup/chronology/counts/costs/pins/schema rules unchanged. Fee1bps,
half-spread2bps and slippage3bps are the existing fixture, not zero costs.
2. Cross-environment reference3.12.3/Windows versus actual container3.12.15:
compare all setup/IDs/window chronology/trades/counts exactly; float metrics,
turnover/returns/costs with explicit existing-validator tolerance rel1e-9/abs1e-12,
including matching None semantics. Test report projection only omits created_at
and the two expected-to-differ runtime evidence digests; it is never published
or used to weaken canonical_result. Different dependency/Python fingerprints
must stay different. Root may freeze a stricter tolerance if fixture proves exact.
3. Two independent jobs/attempts with the same request/engine/image must emit
identical existing canonical_result bytes and envelope hashes, while per-attempt
created_at/owner/CID/receipts differ. No image/CID/owner/attempt/host clock is added
to canonical identity, and no host runtime is forced into the receipt.

## Minimal implementation paths for the next authorization

| Proposed path | Exact responsibility/dependency |
| --- | --- |
| src/quantmesh/research/job_runner.py | runtime_fingerprint optional manifest path; _OwnedChild poll/pulse adapter and -B/env1; Windows _child_command retains go; _child_main separatesRO input/RW output while default Windows layout stays; run_next_job chooses constructor context, stores actual poll code,1s pulses, image-bound runtime, bounded receipt checks. Public signature unchanged. |
| src/quantmesh/research/worker_execution.py (new) | Frozen construction wrapper/private ContextVar, OwnedAttempt adapters and Linux execution selection. Needed to preserve four-arg function without mutable globals/DTO/env inference. |
| src/quantmesh/research/worker_build.py (new, stdlib) | Manifest/inventory validation and actual container fingerprint, independent of Git/report mathematics. Needed because job_runner's existing Git/host fingerprint cannot work inside image. |
| deploy/research_worker/Dockerfile + worker_entry.py (new) | Finite offline image and fixed stdlib-first trusted launcher; cleanenv thread limits, -B, RO/RW paths. |
| deploy/research_worker/prepare.py + image-admission.py (new) | Exact Git/lock/wheel/context sealing, offline full runtime/notices/ELF inventory, external immutable admission/probe binding. These producer scripts do not exist yet and are not implemented by this packet. |
| tests/test_research_job_runner.py | Add explicit-context/no-profile/common poll and path regressions; retain Windows OS witnesses/skip distinction. |
| tests/test_worker_build.py (new) | Missing .git manifest path; byte/source/RECORD/Python/image/probe mismatch refusal and unchanged runtime shape. |
| tools/qualify_linux_worker_jobs.py (new) | Opt-in actual numerical/two-job owner-crash witness and durable sanitized evidence; no default/native execution this round. |
| docs/runbooks/linux-research-worker.md | Root-approved measured Task2 interface/result/limits, after implementation evidence. |

No modification is proposed to jobs.py/job_store.py/job_artifacts.py/strategy_registry.py/
baselines.py/reports.py/linux_owned.py/linux_bootstrap.py, API/routes/SDK,
service runtime/adapter or any lock. Their bytes are regression inputs/invariants.
If a producer genuinely needs one of those shared paths, report the concrete
dependency/RED/patch to root before expanding. No speculative broad refactor.

## Root freeze decisions and remaining gates

Freeze: construction wrapper/ContextVar interface; full-base retention including
GNU/pip licenses; five-field actual runtime + separate external image admission;
RO bundle/RW output layout; numerical comparison tolerances and native witness
start/end timestamps. Named blocked gates: final5GB storage attribution/acceptance;
actual Debian notice resolution; newly built Python3.12.15/wheel ELF/import proof;
source/current implementation exact commit and image byte admission; fresh
numerical image-bound native qualification and<=90s recovery/publication proof.
Metadata-ready is not image-ready. Task1 native15/15 remains its stdlib scope;
this packet grants no numerical, server/provider/AWS/wholeA certificate.

IMPLEMENTATION-CHECKLIST.md supplies proposed bounded RED/GREEN and actual witness
steps; every checkbox is pending. Root reviews/finalizes this concrete packet,
then authorizes a later independent implementation slice. No extra human question
or duplicate disk question is needed to deliver this proposal.
