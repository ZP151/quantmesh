import datetime,gzip,hashlib,json,os,re,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CAP=2000000
MAX_RESPONSE=12*1024*1024
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
def fetch(url,headers=None):
 with urllib.request.urlopen(urllib.request.Request(url,headers=headers or {}),timeout=30) as response:
  data=response.read(MAX_RESPONSE+1)
  assert len(data)<=MAX_RESPONSE,'metadata_response_bound'
  return data,dict(response.headers)
def save(name,data):
 if (ROOT/name).exists():
  assert (ROOT/name).read_bytes()==data,'immutable_content_changed'
  return 'sha256:'+hashlib.sha256(data).hexdigest()
 current=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
 assert current+len(data)<=CAP,'two_MB_packet_limit'
 (ROOT/name).write_bytes(data)
 return 'sha256:'+hashlib.sha256(data).hexdigest()
def jsave(name,value):return save(name,(json.dumps(value,indent=2)+'\n').encode())
library,_=fetch('https://raw.githubusercontent.com/docker-library/official-images/master/library/python')
save('official-python-library.txt',library)
blocks=library.decode().split('\n\n')
block=next(b for b in blocks if re.search(r'^Tags: .*3\.12\.[0-9]+-slim-bookworm(?:,|$)',b,re.M))
tags=re.search(r'^Tags: (.+)',block,re.M).group(1).split(', ')
tag=next(t for t in tags if re.fullmatch(r'3\.12\.[0-9]+-slim-bookworm',t))
commit=re.search(r'^GitCommit: (\S+)',block,re.M).group(1)
directory=re.search(r'^Directory: (\S+)',block,re.M).group(1)
url=f'https://raw.githubusercontent.com/docker-library/python/{commit}/{directory}/Dockerfile'
recipe,_=fetch(url);recipe_sha=save('official-python-Dockerfile',recipe)
licurl=f'https://raw.githubusercontent.com/docker-library/python/{commit}/LICENSE'
lic,_=fetch(licurl);licsha=save('official-python-packaging-LICENSE',lic)
version=re.search(rb'ENV PYTHON_VERSION (\S+)',recipe).group(1).decode()
source_sha=re.search(rb'ENV PYTHON_SHA256 (\S+)',recipe).group(1).decode()
cpurl=f'https://raw.githubusercontent.com/python/cpython/v{version}/LICENSE'
cpl,_=fetch(cpurl);cpsha=save('CPython-LICENSE',cpl)
noturl=f'https://raw.githubusercontent.com/python/cpython/v{version}/Doc/license.rst'
notices,_=fetch(noturl);notsha=save('CPython-third-party-licenses.rst',notices)
token_bytes,_=fetch('https://auth.docker.io/token?service=registry.docker.io&scope=repository:library/python:pull')
token=json.loads(token_bytes)['token']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json'}
registry='https://registry-1.docker.io/v2/library/python/'
idx,ih=fetch(registry+'manifests/'+tag,headers);idxsha=save('registry-index.json',idx)
assert next((v for k,v in ih.items() if k.lower()=='docker-content-digest'),None)==idxsha
index=json.loads(idx)
amd64=next(m for m in index['manifests'] if m.get('platform')=={'architecture':'amd64','os':'linux'})
def descriptor(route,desc,name,compressed=False):
 data,_=fetch(registry+route+desc['digest'],headers)
 assert 'sha256:'+hashlib.sha256(data).hexdigest()==desc['digest'] and len(data)==desc['size'],'descriptor_mismatch'
 stored=gzip.compress(data,mtime=0) if compressed else data
 save(name,stored)
 return json.loads(data),dict(file=name,raw_digest=desc['digest'],raw_bytes=len(data),stored_bytes=len(stored),stored_sha256=hashlib.sha256(stored).hexdigest())
manifest,mmeta=descriptor('manifests/',amd64,'amd64-manifest.json')
config,cmeta=descriptor('blobs/',manifest['config'],'amd64-config.json')
att=[];packages=[];files=0;sbom=None;provenance=None
for i,m in enumerate(index['manifests']):
 if m.get('annotations',{}).get('vnd.docker.reference.digest')!=amd64['digest']:continue
 am,ameta=descriptor('manifests/',m,f'attestation-{i}-manifest.json')
 for j,l in enumerate(am['layers']):
  if l['mediaType']!='application/vnd.in-toto+json':continue
  doc,meta=descriptor('blobs/',l,f'attestation-{i}-{j}.json.gz',True)
  meta['predicate_type']=doc.get('predicateType');att.append(meta)
  assert any(s.get('digest',{}).get('sha256')==amd64['digest'].removeprefix('sha256:') for s in doc.get('subject',[]))
  if 'spdx' in doc.get('predicateType','').lower():
   sbom=doc['predicate'];files=len(sbom.get('files',[]))
   for p in sbom.get('packages',[]):
    packages.append({k:p.get(k) for k in ['SPDXID','name','versionInfo','licenseDeclared','licenseConcluded','downloadLocation','sourceInfo','externalRefs']})
  if 'slsa' in doc.get('predicateType','').lower():provenance=doc['predicate']
assert sbom is not None and provenance is not None
jsave('base-packages.json',packages)
jsave('provenance-summary.json',{k:provenance.get(k) for k in ['buildType','builder','materials','invocation','metadata']})
record=dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),status='OFFICIAL_METADATA_VERIFIED_NOT_MATERIALIZED',tag_for_discovery=tag,index_digest=idxsha,linux_amd64_manifest_digest=amd64['digest'],image_config_digest=manifest['config']['digest'],compressed_runtime_layer_bytes=sum(l['size'] for l in manifest['layers']),runtime_layers=manifest['layers'],official_packaging_git_commit=commit,official_directory=directory,official_dockerfile_url=url,official_dockerfile_sha256=recipe_sha,packaging_license_url=licurl,packaging_license_sha256=licsha,python_version=version,cpython_source_tar_sha256=source_sha,cpython_source_tar_downloaded=False,cpython_license_url=cpurl,cpython_license_sha256=cpsha,cpython_notices_url=noturl,cpython_notices_sha256=notsha,config_env=config.get('config',{}).get('Env'),config_volumes=config.get('config',{}).get('Volumes'),attestations=att,sbom_packages=len(packages),sbom_files=files,verified_subject_manifest=True,runtime_layers_downloaded=False,wheels_downloaded=False,docker_operations=False,new_environment=False,local_resource_acceptance='PENDING: previous whole-C conservative delta unexplained; metadata packet only')
jsave('registry-intake.json',record)
print(json.dumps({k:record[k] for k in ['status','tag_for_discovery','linux_amd64_manifest_digest','python_version','compressed_runtime_layer_bytes','sbom_packages','sbom_files']}))

