import datetime,gzip,hashlib,io,json,os,subprocess,sys,tarfile
from pathlib import Path
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
root=Path.cwd();packet=root/'output/172-task2-proposal-20261013'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='f818a553c024169b2e3a61dcd6fa8941774cf43b'
assert not subprocess.check_output(['git','status','--porcelain=v1'],text=True).strip()
registry=json.loads((packet/'registry-intake.json').read_text())
for meta in registry['attestations']:
 path=packet/meta['file'];stored=path.read_bytes();raw=gzip.decompress(stored)
 assert len(stored)==meta['stored_bytes'] and hashlib.sha256(stored).hexdigest()==meta['stored_sha256']
 assert len(raw)==meta['raw_bytes'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==meta['raw_digest']
 doc=json.loads(raw)
 assert any(s.get('digest',{}).get('sha256')==registry['linux_amd64_manifest_digest'].removeprefix('sha256:') for s in doc['subject'])
for name,digest in [('registry-index.json',registry['index_digest']),('amd64-manifest.json',registry['linux_amd64_manifest_digest']),('amd64-config.json',registry['image_config_digest']),('official-python-Dockerfile',registry['official_dockerfile_sha256']),('CPython-LICENSE',registry['cpython_license_sha256']),('CPython-third-party-licenses.rst',registry['cpython_notices_sha256'])]:
 assert 'sha256:'+hashlib.sha256((packet/name).read_bytes()).hexdigest()==digest
facts=json.loads((packet/'source-abi-facts.json').read_text())
assert facts['wheel_count']==81 and facts['binary_tagged_wheels']==19 and facts['maximum_declared_glibc_tag']==[2,34]
for entry in facts['source_files']:
 raw=subprocess.check_output(['git','show',facts['source_commit']+':'+entry['path']])
 assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
for p in packet.glob('*.json'):json.loads(p.read_text(encoding='utf-8-sig'))
files=[]
for p in sorted(packet.iterdir()):
 if not p.is_file():raise AssertionError('unexpected_packet_directory')
 raw=p.read_bytes();files.append(dict(path=p.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
closure=dict(status='PROPOSAL_ONLY',read_source_commit=facts['source_commit'],local_HEAD='f818a553c024169b2e3a61dcd6fa8941774cf43b',worktree_clean=True,metadata_verified_not_materialized=True,no_product_code_or_native_tests=True,files=files,self_hash_rule='HASHINDEX plus sidecar/packet index/archive are outside pre-seal member list',bound_new_bytes=2000000,resource_acceptance='PENDING: preexisting unexplained whole-C delta not reclassified',root_freeze='PENDING')
index_bytes=(json.dumps(closure,indent=2)+'\n').encode()
manifest_hash=hashlib.sha256(index_bytes).hexdigest()
(packet/'HASHINDEX.json').write_bytes(index_bytes)
(packet/'HASHINDEX.sha256').write_text(manifest_hash+'  HASHINDEX.json\n')
stream=io.BytesIO()
with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for entry in files+[dict(path='HASHINDEX.json'),dict(path='HASHINDEX.sha256')]:
   raw=(packet/entry['path']).read_bytes();info=tarfile.TarInfo(entry['path']);info.size=len(raw);info.mode=0o644;info.mtime=0
   tar.addfile(info,io.BytesIO(raw))
archive=stream.getvalue()
current=sum(p.stat().st_size for p in packet.iterdir() if p.is_file())
assert current+len(archive)+12000<2000000,'metadata_packet_total_exceeds_two_MB'
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 expected={e['path']:e for e in files}
 assert len(tar.getmembers())==len(files)+2
 for member in tar:
  raw=tar.extractfile(member).read()
  if member.name in expected:assert hashlib.sha256(raw).hexdigest()==expected[member.name]['sha256']
  elif member.name=='HASHINDEX.json':assert raw==index_bytes
  else:assert raw==(packet/'HASHINDEX.sha256').read_bytes()
archive_path=packet/'task2-proposal.tar.gz';archive_path.write_bytes(archive)
packet_index=dict(status='PROPOSAL_ONLY',created_at_asia_singapore=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),source_commit=facts['source_commit'],local_HEAD=closure['local_HEAD'],archive=archive_path.name,archive_bytes=len(archive),archive_sha256=hashlib.sha256(archive).hexdigest(),archive_members=len(files)+2,HASHINDEX_sha256=manifest_hash,total_packet_bytes_before_index=current+len(archive),packet_limit_bytes=2000000,metadata_base_manifest=registry['linux_amd64_manifest_digest'],metadata_config_digest=registry['image_config_digest'],wheel_count=81,metadata_verified=True,materialized=False,new_native_tests=False,product_code_modified=False,worktree_clean=True,root_freeze='PENDING',storage_acceptance='PENDING',final_notice_ELF_runtime_acceptance='PENDING',privacy='public metadata and exact source references only; no Engine unrelated workload inventory/credential values')
(packet/'PACKET-INDEX.json').write_text(json.dumps(packet_index,indent=2)+'\n')
assert sum(p.stat().st_size for p in packet.iterdir() if p.is_file())<2000000
print(json.dumps(dict(archive_bytes=len(archive),archive_sha256=packet_index['archive_sha256'],archive_members=packet_index['archive_members'],HASHINDEX_sha256=manifest_hash,total_packet_bytes=sum(p.stat().st_size for p in packet.iterdir() if p.is_file()),worktree_clean=True,proposal_only=True)))
